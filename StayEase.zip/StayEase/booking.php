<?php
// - booking.php -
require_once 'config.php';
session_start();

$preselect = (int) ($_GET['hotel_id'] ?? $_POST['hotel_id'] ?? 0);

// - AJAX: rooms for a hotel -
if (isset($_GET['get_rooms'])) {
    $hotel_id = (int) $_GET['hotel_id'];
    $stmt = $conn->prepare(
        "SELECT room_id, room_number, room_details, room_price, capacity, area
         FROM Room WHERE hotel_id = ? AND available = 1 ORDER BY room_price"
    );
    $stmt->bind_param('i', $hotel_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rooms = [];
    while ($row = $result->fetch_assoc()) $rooms[] = $row;
    header('Content-Type: application/json');
    echo json_encode($rooms);
    exit;
}

// - Fetch hotels -
$hotels = $conn->query("SELECT hotel_id, hotel_name, hotel_city FROM Hotel ORDER BY hotel_city, hotel_name");

// - Form submission -
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name      = trim($_POST['name']      ?? '');
    $username  = trim($_POST['username']  ?? '');
    $password  = trim($_POST['password']  ?? '');
    $room_id   = (int) ($_POST['room_id'] ?? 0);
    $check_in  = $_POST['check_in']  ?? '';
    $check_out = $_POST['check_out'] ?? '';

    if (!$name || !$username || !$password || !$room_id || !$check_in || !$check_out) {
        $error = 'Please fill in all required fields.';
    } elseif ($check_in >= $check_out) {
        $error = 'Check-out date must be after check-in.';
    } else {
        $user_id = null;

        // If already logged in, use session user
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
        } else {
            $stmt = $conn->prepare("SELECT user_id, password FROM User WHERE username = ?");
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();

            if ($row) {
                if (!password_verify($password, $row['password'])) {
                    $error = 'Incorrect password for that username.';
                } else {
                    $user_id = $row['user_id'];
                    $_SESSION['user_id']   = $user_id;
                    $_SESSION['user_name'] = $username;
                }
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $ins = $conn->prepare("INSERT INTO User (name, username, password) VALUES (?,?,?)");
                $ins->bind_param('sss', $name, $username, $hashed);
                $ins->execute();
                $user_id = $conn->insert_id;
                $_SESSION['user_id']   = $user_id;
                $_SESSION['user_name'] = $username;
            }
        }

        if ($user_id && !$error) {
            $rs = $conn->prepare("SELECT room_price FROM Room WHERE room_id = ? AND available = 1");
            $rs->bind_param('i', $room_id);
            $rs->execute();
            $room_row = $rs->get_result()->fetch_assoc();

            if (!$room_row) {
                $error = 'Selected room is no longer available.';
            } else {
                $nights = (strtotime($check_out) - strtotime($check_in)) / 86400;
                $total  = $room_row['room_price'] * $nights;

                $bstmt = $conn->prepare(
                    "INSERT INTO Booking (user_id, room_id, check_in, check_out, booking_price, status)
                     VALUES (?,?,?,?,?,'pending')"
                );
                $bstmt->bind_param('iissd', $user_id, $room_id, $check_in, $check_out, $total);

                if ($bstmt->execute()) {
                    $booking_id = $conn->insert_id;
                    $success = "Booking #$booking_id confirmed — EGP " . number_format($total, 2) . " for $nights night(s).";
                } else {
                    $error = 'Booking could not be saved. Please try again.';
                }
            }
        }
    }
}

// - Logged-in user name for pre-fill -
$session_name     = $_SESSION['user_name'] ?? '';
$session_user_id  = $_SESSION['user_id']   ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Book a Room — StayEase</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --gold:       #C9A96E;
  --gold-light: #E8D5B0;
  --gold-dark:  #8B6914;
  --navy:       #0D1B2A;
  --navy-mid:   #1A2E42;
  --navy-soft:  #243447;
  --cream:      #FAF7F2;
  --cream-mid:  #F0EBE1;
  --text-dark:  #0D1B2A;
  --text-mid:   #4A5568;
  --text-light: #8A9BA8;
  --white:      #FFFFFF;
}

body {
  font-family: 'DM Sans', sans-serif;
  background-color: var(--cream);
  color: var(--text-dark);
  line-height: 1.6;
  min-height: 100vh;
}

a { text-decoration: none; }
ul { list-style: none; }

/* - NAV - */
header {
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 100;
  border-bottom: 1px solid rgba(201,169,110,0.2);
  background: rgba(13,27,42,0.95);
  backdrop-filter: blur(12px);
}

nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 72px;
  padding: 0 60px;
}

.home-logo {
  font-family: 'Cormorant Garamond', serif;
  font-size: 30px;
  font-weight: 500;
  color: var(--gold);
  letter-spacing: 2px;
}
.home-logo span { color: var(--white); }

.nav-links { display: flex; gap: 36px; }
.nav-links a {
  color: rgba(255,255,255,0.75);
  font-size: 14px;
  letter-spacing: 0.5px;
  transition: color 0.2s;
}
.nav-links a:hover { color: var(--gold); }

.home-login { display: flex; gap: 12px; align-items: center; }

.home-signinBtn {
  padding: 8px 20px;
  border: 1px solid rgba(201,169,110,0.5);
  color: var(--gold);
  background: transparent;
  border-radius: 4px;
  font-family: 'DM Sans', sans-serif;
  font-size: 14px;
  transition: background 0.2s;
}
.home-signinBtn:hover { background: rgba(201,169,110,0.1); }

.home-registerBtn {
  padding: 8px 20px;
  background: var(--gold);
  color: var(--navy);
  border: none;
  border-radius: 4px;
  font-family: 'DM Sans', sans-serif;
  font-size: 14px;
  font-weight: 500;
  transition: background 0.2s;
}
.home-registerBtn:hover { background: var(--gold-light); }

/* - PAGE HERO BANNER - */
.booking-hero {
  padding-top: 72px;
  background: var(--navy);
  position: relative;
  overflow: hidden;
}
.booking-hero-bg {
  position: absolute; inset: 0;
  background-image: url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1600&q=80');
  background-size: cover;
  background-position: center;
  opacity: 0.12;
}
.booking-hero-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to bottom, rgba(13,27,42,0.5), rgba(13,27,42,0.9));
}
.booking-hero-content {
  position: relative;
  z-index: 2;
  padding: 60px 60px 48px;
}
.booking-hero-tag {
  font-size: 11px;
  letter-spacing: 4px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 12px;
}
.booking-hero-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: 56px;
  font-weight: 300;
  color: var(--white);
  line-height: 1.1;
  margin-bottom: 12px;
}
.booking-hero-title em { font-style: italic; color: var(--gold); }
.booking-hero-sub {
  font-size: 15px;
  color: rgba(255,255,255,0.5);
  max-width: 480px;
}

/* - MAIN LAYOUT - */
.booking-layout {
  display: grid;
  grid-template-columns: 1fr 360px;
  gap: 32px;
  max-width: 1100px;
  margin: 0 auto;
  padding: 48px 32px 80px;
}

/* - SECTION LABELS - */
.section-tag {
  font-size: 11px;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 8px;
}
.section-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: 28px;
  font-weight: 400;
  color: var(--text-dark);
  margin-bottom: 24px;
  line-height: 1.2;
}

/* - FORM PANELS - */
.booking-panel {
  background: var(--white);
  border-radius: 4px;
  padding: 36px;
  box-shadow: 0 4px 24px rgba(13,27,42,0.07);
  margin-bottom: 24px;
}

/* - FORM ELEMENTS - */
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.form-full { grid-column: 1 / -1; }

label {
  display: block;
  font-size: 11px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: var(--text-light);
  font-weight: 500;
  margin-bottom: 8px;
}

input, select {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid var(--cream-mid);
  border-radius: 4px;
  font-size: 14px;
  font-family: 'DM Sans', sans-serif;
  background: var(--cream);
  color: var(--text-dark);
  transition: border-color 0.2s;
}
input:focus, select:focus {
  outline: none;
  border-color: var(--gold);
  background: var(--white);
}

select option { background: var(--white); }

/* - DIVIDER - */
.panel-divider {
  border: none;
  border-top: 1px solid var(--cream-mid);
  margin: 28px 0;
}

/* - ROOM CARDS - */
#room-section { display: none; }
#room-section.visible { display: block; }

.room-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px; }

.room-card {
  border: 1px solid var(--cream-mid);
  border-radius: 4px;
  padding: 18px;
  cursor: pointer;
  transition: border-color 0.2s, background 0.2s;
}
.room-card:hover { border-color: var(--gold); background: #FFFDF9; }
.room-card.selected { border-color: var(--gold); background: #FFFDF9; }
.room-card.selected::after {
  content: '';
  display: block;
  width: 100%;
  height: 2px;
  background: var(--gold);
  margin-top: 14px;
  border-radius: 2px;
}

.room-number {
  font-family: 'Cormorant Garamond', serif;
  font-size: 18px;
  font-weight: 500;
  color: var(--text-dark);
  margin-bottom: 6px;
}
.room-badges { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
.room-badge {
  font-size: 10px;
  letter-spacing: 1px;
  text-transform: uppercase;
  padding: 3px 8px;
  background: var(--cream-mid);
  color: var(--text-mid);
  border-radius: 2px;
}
.room-price {
  font-family: 'Cormorant Garamond', serif;
  font-size: 22px;
  font-weight: 400;
  color: var(--gold-dark);
  margin-bottom: 6px;
}
.room-price span {
  font-family: 'DM Sans', sans-serif;
  font-size: 12px;
  color: var(--text-light);
  font-weight: 400;
}
.room-detail {
  font-size: 12px;
  color: var(--text-light);
  line-height: 1.6;
}

/* - LOADER - */
.loader {
  padding: 20px 0;
  font-size: 13px;
  color: var(--text-light);
  letter-spacing: 1px;
  display: none;
}

/* - ALERTS - */
.alert {
  padding: 14px 18px;
  border-radius: 4px;
  font-size: 14px;
  margin-bottom: 24px;
  border-left: 3px solid;
}
.alert-success { background: #F0FAF4; border-color: var(--gold); color: var(--gold-dark); }
.alert-error   { background: #FDF0F0; border-color: #C0392B;    color: #7B2020; }

/* - SUBMIT BUTTON - */
.btn-book {
  width: 100%;
  padding: 16px;
  background: var(--gold);
  color: var(--navy);
  border: none;
  border-radius: 4px;
  font-family: 'Cormorant Garamond', serif;
  font-size: 18px;
  font-weight: 500;
  letter-spacing: 1px;
  cursor: pointer;
  transition: background 0.2s;
  margin-top: 8px;
}
.btn-book:hover { background: var(--gold-light); }

/* - SIDEBAR - */
.booking-sidebar { position: sticky; top: 100px; align-self: start; }

.sidebar-card {
  background: var(--navy);
  border-radius: 4px;
  padding: 32px;
  margin-bottom: 20px;
}
.sidebar-card-title {
  font-size: 11px;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 20px;
}
.sidebar-summary-row {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  font-size: 13px;
  color: rgba(255,255,255,0.5);
  padding: 8px 0;
  border-bottom: 1px solid rgba(255,255,255,0.06);
}
.sidebar-summary-row:last-of-type { border-bottom: none; }
.sidebar-summary-val { color: var(--white); font-weight: 500; }
.sidebar-total {
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid rgba(201,169,110,0.3);
  display: flex;
  justify-content: space-between;
  align-items: baseline;
}
.sidebar-total-label {
  font-size: 11px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: var(--gold);
}
.sidebar-total-price {
  font-family: 'Cormorant Garamond', serif;
  font-size: 32px;
  color: var(--white);
}
.sidebar-total-price span {
  font-family: 'DM Sans', sans-serif;
  font-size: 12px;
  color: rgba(255,255,255,0.4);
}

.sidebar-note {
  background: var(--cream-mid);
  border-radius: 4px;
  padding: 20px 24px;
}
.sidebar-note p {
  font-size: 12px;
  color: var(--text-mid);
  line-height: 1.7;
  margin-bottom: 6px;
}
.sidebar-note p:last-child { margin-bottom: 0; }
.sidebar-note strong { color: var(--text-dark); font-weight: 500; }

/* - GUEST INFO NOTE - */
.guest-note {
  font-size: 12px;
  color: var(--text-light);
  margin-top: 8px;
  line-height: 1.6;
}

@media (max-width: 820px) {
  .booking-layout { grid-template-columns: 1fr; padding: 32px 20px 60px; }
  .booking-sidebar { position: static; }
  nav { padding: 0 20px; }
  .nav-links { display: none; }
  .booking-hero-content { padding: 48px 20px 36px; }
  .booking-hero-title { font-size: 38px; }
  .room-grid { grid-template-columns: 1fr; }
  .form-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<header>
  <nav>
    <a href="home.php" class="home-logo">Stay<span>Ease</span></a>
    <ul class="nav-links">
      <li><a href="hotels.php">Hotels</a></li>
      <li><a href="home.php#amenities">Amenities</a></li>
      <li><a href="home.php#about">About</a></li>
      <li><a href="home.php#contact">Contact</a></li>
    </ul>
    <div class="home-login">
    <?php if ($session_user_id): ?>
        <span style="color:rgba(255,255,255,0.6);font-size:14px;">
            Welcome, <?= htmlspecialchars($session_name ?? 'Guest') ?>
        </span>
        <a href="logout.php" class="home-signinBtn">Sign Out</a>
    <?php else: ?>
        <a href="login.php" class="home-signinBtn">Sign In</a>
        <a href="register.php" class="home-registerBtn">Register</a>
    <?php endif; ?>
</div>
  </nav>
</header>

<div class="booking-hero">
  <div class="booking-hero-bg"></div>
  <div class="booking-hero-overlay"></div>
  <div class="booking-hero-content">
    <p class="booking-hero-tag">Reservations</p>
    <h1 class="booking-hero-title">Book Your <em>Perfect</em> Stay</h1>
    <p class="booking-hero-sub">Select your hotel, choose a room, and confirm your reservation in moments.</p>
  </div>
</div>

<div class="booking-layout">

  <!-- - MAIN FORM COLUMN - -->
  <div class="booking-main">

    <?php if ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" id="booking-form">

      <!-- Panel 1: Hotel & Dates -->
      <div class="booking-panel">
        <p class="section-tag">Step 1</p>
        <h2 class="section-title">Choose Hotel &amp; Dates</h2>

        <div class="form-grid">
          <div class="form-full">
            <label for="hotel_id">Hotel</label>
            <select id="hotel_id" name="hotel_id" required>
              <option value="">Select a hotel</option>
              <?php while ($h = $hotels->fetch_assoc()): ?>
                <option value="<?= $h['hotel_id'] ?>"
                  <?= ($h['hotel_id'] == $preselect) ? 'selected' : '' ?>>
                  <?= htmlspecialchars($h['hotel_name']) ?> — <?= htmlspecialchars($h['hotel_city']) ?>
                </option>
              <?php endwhile; ?>
            </select>
          </div>

          <div>
            <label for="check_in">Check-in</label>
            <input type="date" id="check_in" name="check_in"
                   min="<?= date('Y-m-d') ?>"
                   value="<?= htmlspecialchars($_POST['check_in'] ?? '') ?>" required>
          </div>
          <div>
            <label for="check_out">Check-out</label>
            <input type="date" id="check_out" name="check_out"
                   value="<?= htmlspecialchars($_POST['check_out'] ?? '') ?>" required>
          </div>
        </div>
      </div>

      <!-- Panel 2: Room Selection -->
      <div class="booking-panel" id="room-section">
        <p class="section-tag">Step 2</p>
        <h2 class="section-title">Select Your Room</h2>
        <p class="loader" id="room-loader">Loading available rooms...</p>
        <div id="room-grid" class="room-grid"></div>
        <input type="hidden" id="room_id" name="room_id" value="<?= (int)($_POST['room_id'] ?? 0) ?>">
      </div>

      <!-- Panel 3: Guest Details -->
      <div class="booking-panel">
        <p class="section-tag">Step 3</p>
        <h2 class="section-title">Guest Details</h2>

        <?php if ($session_user_id): ?>
          <p class="guest-note">You are signed in as <strong><?= htmlspecialchars($session_name) ?></strong>. Your booking will be linked to this account.</p>
          <input type="hidden" name="name"     value="<?= htmlspecialchars($session_name) ?>">
          <input type="hidden" name="username" value="<?= htmlspecialchars($session_name) ?>">
          <input type="hidden" name="password" value="__session__">
        <?php else: ?>
          <div class="form-grid">
            <div>
              <label for="name">Full Name</label>
              <input type="text" id="name" name="name" placeholder="Ahmed Hassan"
                     value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
            </div>
            <div>
              <label for="username">Username</label>
              <input type="text" id="username" name="username" placeholder="ahmed99"
                     value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
            </div>
            <div class="form-full">
              <label for="password">Password</label>
              <input type="password" id="password" name="password" placeholder="Sign in or create a new account" required>
            </div>
          </div>
          <p class="guest-note">Enter your existing account credentials to sign in, or choose a new username and password to create an account automatically.</p>
        <?php endif; ?>

        <hr class="panel-divider">
        <button type="submit" class="btn-book">Confirm Reservation</button>
      </div>

    </form>
  </div>

  <!-- - SIDEBAR - -->
  <aside class="booking-sidebar">
    <div class="sidebar-card">
      <p class="sidebar-card-title">Booking Summary</p>

      <div class="sidebar-summary-row">
        <span>Hotel</span>
        <span class="sidebar-summary-val" id="sum-hotel">—</span>
      </div>
      <div class="sidebar-summary-row">
        <span>Room</span>
        <span class="sidebar-summary-val" id="sum-room">—</span>
      </div>
      <div class="sidebar-summary-row">
        <span>Check-in</span>
        <span class="sidebar-summary-val" id="sum-checkin">—</span>
      </div>
      <div class="sidebar-summary-row">
        <span>Check-out</span>
        <span class="sidebar-summary-val" id="sum-checkout">—</span>
      </div>
      <div class="sidebar-summary-row">
        <span>Nights</span>
        <span class="sidebar-summary-val" id="sum-nights">—</span>
      </div>

      <div class="sidebar-total">
        <span class="sidebar-total-label">Total</span>
        <span class="sidebar-total-price" id="sum-total">— <span>EGP</span></span>
      </div>
    </div>

    <div class="sidebar-note">
      <p><strong>Free Cancellation</strong> up to 48 hours before check-in.</p>
      <p>Booking status starts as <strong>Pending</strong> and is confirmed within 2 hours.</p>
      <p>All prices are inclusive of taxes and service charges.</p>
    </div>
  </aside>

</div>

<!-- - FOOTER - -->
<footer id="contact" style="background:var(--navy);padding:64px 60px 32px;border-top:1px solid rgba(201,169,110,0.15);">
  <div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:48px;margin-bottom:48px;">
    <div>
      <p style="font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:500;color:var(--gold);margin-bottom:12px;">StayEase</p>
      <p style="font-size:13px;color:rgba(255,255,255,0.4);line-height:1.7;max-width:240px;">The modern way to discover and book premium hotel accommodations worldwide.</p>
    </div>
    <div>
      <h4 style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:var(--gold);margin-bottom:20px;font-weight:500;">Quick Links</h4>
      <ul style="display:flex;flex-direction:column;gap:12px;">
        <li><a href="hotels.php" style="font-size:13px;color:rgba(255,255,255,0.5);transition:color .2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">All Hotels</a></li>
        <li><a href="login.php"  style="font-size:13px;color:rgba(255,255,255,0.5);transition:color .2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">Sign In</a></li>
        <li><a href="register.php" style="font-size:13px;color:rgba(255,255,255,0.5);transition:color .2s;" onmouseover="this.style.color='var(--gold)'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">Register</a></li>
      </ul>
    </div>
    <div>
      <h4 style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:var(--gold);margin-bottom:20px;font-weight:500;">Contact Us</h4>
      <p style="font-size:13px;color:rgba(255,255,255,0.5);">stayease@gmail.com</p>
    </div>
  </div>
  <div style="display:flex;justify-content:space-between;padding-top:24px;border-top:1px solid rgba(255,255,255,0.08);">
    <p style="font-size:12px;color:rgba(255,255,255,0.3);">© 2025 StayEase. All rights reserved.</p>
    <p style="font-size:12px;color:rgba(255,255,255,0.3);">Built for exceptional stays.</p>
  </div>
</footer>

<script>
const hotelSel  = document.getElementById('hotel_id');
const roomSect  = document.getElementById('room-section');
const roomGrid  = document.getElementById('room-grid');
const roomInput = document.getElementById('room_id');
const loader    = document.getElementById('room-loader');
const checkIn   = document.getElementById('check_in');
const checkOut  = document.getElementById('check_out');

// Sidebar elements
const sumHotel   = document.getElementById('sum-hotel');
const sumRoom    = document.getElementById('sum-room');
const sumCheckin  = document.getElementById('sum-checkin');
const sumCheckout = document.getElementById('sum-checkout');
const sumNights  = document.getElementById('sum-nights');
const sumTotal   = document.getElementById('sum-total');

let selectedPrice = 0;
let selectedRoomNum = '';

function formatDate(val) {
  if (!val) return '—';
  const d = new Date(val + 'T00:00:00');
  return d.toLocaleDateString('en-EG', { day:'numeric', month:'short', year:'numeric' });
}

function updateSidebar() {
  const hotelText = hotelSel.options[hotelSel.selectedIndex]?.text || '—';
  sumHotel.textContent  = hotelSel.value ? hotelText.split('—')[0].trim() : '—';
  sumRoom.textContent   = selectedRoomNum || '—';
  sumCheckin.textContent  = formatDate(checkIn.value);
  sumCheckout.textContent = formatDate(checkOut.value);

  if (checkIn.value && checkOut.value && checkOut.value > checkIn.value) {
    const nights = Math.round((new Date(checkOut.value) - new Date(checkIn.value)) / 86400000);
    sumNights.textContent = nights + (nights === 1 ? ' night' : ' nights');
    if (selectedPrice) {
      const total = (selectedPrice * nights).toLocaleString('en-EG', { minimumFractionDigits: 2 });
      sumTotal.innerHTML = 'EGP ' + total;
    } else {
      sumTotal.innerHTML = '— <span>EGP</span>';
    }
  } else {
    sumNights.textContent = '—';
    sumTotal.innerHTML = '— <span>EGP</span>';
  }
}

checkIn.addEventListener('change', () => {
  if (checkIn.value) {
    const next = new Date(checkIn.value);
    next.setDate(next.getDate() + 1);
    checkOut.min = next.toISOString().split('T')[0];
    if (checkOut.value && checkOut.value <= checkIn.value) checkOut.value = '';
  }
  updateSidebar();
});

checkOut.addEventListener('change', updateSidebar);
hotelSel.addEventListener('change', () => {
  updateSidebar();
  loadRooms();
});

function loadRooms() {
  const hotel_id = hotelSel.value;
  roomGrid.innerHTML = '';
  roomInput.value    = '';
  selectedPrice      = 0;
  selectedRoomNum    = '';

  if (!hotel_id) { roomSect.classList.remove('visible'); return; }

  roomSect.classList.add('visible');
  loader.style.display = 'block';

  fetch('booking.php?get_rooms=1&hotel_id=' + hotel_id)
    .then(r => r.json())
    .then(rooms => {
      loader.style.display = 'none';
      if (!rooms.length) {
        roomGrid.innerHTML = '<p style="font-size:13px;color:var(--text-light);padding:8px 0;">No rooms available for this hotel.</p>';
        return;
      }
      rooms.forEach(r => {
        const card = document.createElement('div');
        card.className = 'room-card';
        card.innerHTML = `
          <div class="room-number">Room ${r.room_number}</div>
          <div class="room-badges">
            <span class="room-badge">${r.capacity} Guest${r.capacity > 1 ? 's' : ''}</span>
            ${r.area ? `<span class="room-badge">${r.area} m&sup2;</span>` : ''}
          </div>
          <div class="room-price">EGP ${Number(r.room_price).toLocaleString('en-EG')}<span> / night</span></div>
          <div class="room-detail">${r.room_details || ''}</div>
        `;
        card.addEventListener('click', () => {
          document.querySelectorAll('.room-card').forEach(c => c.classList.remove('selected'));
          card.classList.add('selected');
          roomInput.value = r.room_id;
          selectedPrice   = r.room_price;
          selectedRoomNum = 'Room ' + r.room_number;
          updateSidebar();
        });
        roomGrid.appendChild(card);
      });

      // Re-select on POST re-render
      const prev = roomInput.value;
      if (prev) {
        roomGrid.querySelectorAll('.room-card').forEach(card => {
          if (card.querySelector('.room-number').textContent.includes(prev)) card.click();
        });
      }
    })
    .catch(() => {
      loader.style.display = 'none';
      roomGrid.innerHTML = '<p style="color:#C0392B;font-size:13px;">Could not load rooms. Please try again.</p>';
    });
}

// Trigger on page load
const urlHotel = new URLSearchParams(location.search).get('hotel_id');
if (urlHotel && !hotelSel.value) hotelSel.value = urlHotel;
if (hotelSel.value) {
  loadRooms();
  updateSidebar();
}
</script>
</body>
</html>
