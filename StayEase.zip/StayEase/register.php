<?php
// - register.php (fixed: split name, email added, layout corrected) -
require_once 'config.php';
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: home.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $username   = trim($_POST['username'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $password   = trim($_POST['password'] ?? '');
    $confirm    = trim($_POST['confirm'] ?? '');
    $dob        = $_POST['dob'] ?? '';

    // Validation
    if (!$first_name || !$last_name || !$username || !$email || !$password || !$confirm) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($username) < 3) {
        $error = 'Username must be at least 3 characters.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        // Check if username or email already exists
        $chk = $conn->prepare("SELECT user_id FROM User WHERE username = ? OR email = ?");
        $chk->bind_param('ss', $username, $email);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $error = 'That username or email is already taken.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $dob_val = $dob ?: null;
            $ins = $conn->prepare("
                INSERT INTO User (first_name, last_name, username, email, password, DOB)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $ins->bind_param('ssssss', $first_name, $last_name, $username, $email, $hashed, $dob_val);

            if ($ins->execute()) {
                $new_id = $conn->insert_id;
                $_SESSION['user_id']   = $new_id;
                $_SESSION['user_name'] = $username;   // keep username for login greeting
                $_SESSION['user_first'] = $first_name; // optional, for personal greeting
                header('Location: home.php');
                exit;
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
        $chk->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register — StayEase</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --gold: #C9A96E; --gold-light: #E8D5B0; --gold-dark: #8B6914;
  --navy: #0D1B2A; --navy-mid: #1A2E42; --navy-soft: #243447;
  --cream: #FAF7F2; --cream-mid: #F0EBE1;
  --text-dark: #0D1B2A; --text-mid: #4A5568; --text-light: #8A9BA8;
  --white: #FFFFFF;
}

body {
  font-family: 'DM Sans', sans-serif;
  background: var(--navy);
  color: var(--text-dark);
  min-height: 100vh;
  display: flex;
  align-items: stretch;
}
a { text-decoration: none; }

.auth-left {
  flex: 1;
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: flex-end;
  padding: 60px;
}
.auth-left-bg {
  position: absolute; inset: 0;
  background-image: url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200&q=80');
  background-size: cover;
  background-position: center;
  opacity: 0.3;
}
.auth-left-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to top, rgba(13,27,42,0.95) 0%, rgba(13,27,42,0.4) 60%, transparent 100%);
}
.auth-left-content { position: relative; z-index: 2; }
.auth-logo {
  font-family: 'Cormorant Garamond', serif;
  font-size: 36px;
  font-weight: 500;
  color: var(--gold);
  letter-spacing: 2px;
  margin-bottom: 20px;
  display: block;
}
.auth-logo span { color: var(--white); }
.auth-left-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: 48px;
  font-weight: 300;
  color: var(--white);
  line-height: 1.1;
  margin-bottom: 14px;
}
.auth-left-title em { font-style: italic; color: var(--gold); }
.auth-left-sub {
  font-size: 14px;
  color: rgba(255,255,255,0.45);
  max-width: 320px;
  line-height: 1.7;
}

.auth-right {
  width: 480px;
  flex-shrink: 0;
  background: var(--cream);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 60px 48px;
  overflow-y: auto;
}
.auth-form-wrap { width: 100%; }
.auth-tag {
  font-size: 11px;
  letter-spacing: 3px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 10px;
}
.auth-title {
  font-family: 'Cormorant Garamond', serif;
  font-size: 40px;
  font-weight: 400;
  color: var(--text-dark);
  margin-bottom: 32px;
  line-height: 1.1;
}

/* FORM GRID – FIXED LAYOUT */
.form-row-2col {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-bottom: 0;
}
.form-full {
  grid-column: 1 / -1;
}

label {
  display: block;
  font-size: 11px;
  letter-spacing: 1.5px;
  text-transform: uppercase;
  color: var(--text-light);
  font-weight: 500;
  margin-bottom: 8px;
}
input, select {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid var(--cream-mid);
  border-radius: 4px;
  font-size: 14px;
  font-family: 'DM Sans', sans-serif;
  background: var(--white);
  color: var(--text-dark);
  transition: border-color 0.2s;
  margin-bottom: 18px;
}
input:focus { outline: none; border-color: var(--gold); }
.btn-auth {
  width: 100%;
  padding: 15px;
  background: var(--gold);
  color: var(--navy);
  border: none;
  border-radius: 4px;
  font-family: 'Cormorant Garamond', serif;
  font-size: 18px;
  font-weight: 500;
  letter-spacing: 1px;
  cursor: pointer;
  transition: background 0.2s;
  margin-top: 4px;
}
.btn-auth:hover { background: var(--gold-light); }
.auth-switch {
  margin-top: 24px;
  text-align: center;
  font-size: 13px;
  color: var(--text-light);
}
.auth-switch a { color: var(--gold-dark); font-weight: 500; }
.auth-switch a:hover { color: var(--gold); }
.alert-error {
  background: #FDF0F0;
  border-left: 3px solid #C0392B;
  color: #7B2020;
  padding: 12px 16px;
  border-radius: 4px;
  font-size: 13px;
  margin-bottom: 20px;
}

@media (max-width: 820px) {
  body { flex-direction: column; }
  .auth-left { min-height: 260px; flex: none; padding: 40px 24px; }
  .auth-right { width: 100%; padding: 40px 24px; }
  .form-row-2col { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<div class="auth-left">
  <div class="auth-left-bg"></div>
  <div class="auth-left-overlay"></div>
  <div class="auth-left-content">
    <a href="home.php" class="auth-logo">Stay<span>Ease</span></a>
    <h1 class="auth-left-title">Your journey <em>begins.</em></h1>
    <p class="auth-left-sub">Create your account and start discovering the world's finest hotel stays.</p>
  </div>
</div>

<div class="auth-right">
  <div class="auth-form-wrap">
    <p class="auth-tag">New Account</p>
    <h2 class="auth-title">Register</h2>

    <?php if ($error): ?>
      <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <!-- First Name + Last Name (2 columns) -->
      <div class="form-row-2col">
        <div>
          <label for="first_name">First Name</label>
          <input type="text" id="first_name" name="first_name"
                 value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>"
                 placeholder="Ahmed" required autofocus>
        </div>
        <div>
          <label for="last_name">Last Name</label>
          <input type="text" id="last_name" name="last_name"
                 value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>"
                 placeholder="Hassan" required>
        </div>
      </div>

      <!-- Username (full width) -->
      <div class="form-full">
        <label for="username">Username</label>
        <input type="text" id="username" name="username"
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
               placeholder="ahmed99" required>
      </div>

      <!-- Email (full width, fixed) -->
      <div class="form-full">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
               placeholder="ahmed@example.com" required>
      </div>

      <!-- Date of Birth -->
      <div class="form-full">
        <label for="dob">Date of Birth <span style="text-transform:none;letter-spacing:0;font-size:10px;">(optional)</span></label>
        <input type="date" id="dob" name="dob"
               value="<?= htmlspecialchars($_POST['dob'] ?? '') ?>"
               max="<?= date('Y-m-d') ?>">
      </div>

      <!-- Password & Confirm (2 columns) -->
      <div class="form-row-2col">
        <div>
          <label for="password">Password</label>
          <input type="password" id="password" name="password"
                 placeholder="At least 6 characters" required>
        </div>
        <div>
          <label for="confirm">Confirm Password</label>
          <input type="password" id="confirm" name="confirm"
                 placeholder="Repeat password" required>
        </div>
      </div>

      <button type="submit" class="btn-auth">Create Account</button>
    </form>

    <p class="auth-switch">
      Already have an account? <a href="login.php">Sign in</a>
    </p>
  </div>
</div>

</body>
</html>