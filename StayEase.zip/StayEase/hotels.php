<?php
// - hotels.php -
require_once 'config.php';
session_start();

// - READ & SANITIZE SEARCH INPUTS -
$search_name   = trim($_GET['hotel']    ?? '');
$search_city   = trim($_GET['city']     ?? '');
$search_checkin  = $_GET['checkin']  ?? '';
$search_checkout = $_GET['checkout'] ?? '';
$search_guests   = intval($_GET['guests'] ?? 0);

// - BUILD QUERY -
// For each hotel we:
//   1. JOIN Room to get room data
//   2. MIN(room_price)  → starting price shown on card
//   3. COUNT(room_id)   → total rooms
//   4. Filter by name/city (LIKE search)
//   5. If guests provided, only show hotels that have at least
//      one room with capacity >= guests
//   6. If checkin/checkout provided, exclude hotels where ALL
//      rooms are booked for those dates (available check)

$params = [];
$types  = '';

$sql = "
    SELECT
        h.hotel_id,
        h.hotel_name,
        h.hotel_address,
        h.hotel_city,
        h.hotel_details,
        h.hotel_rating,
        h.hotel_image,
        MIN(r.room_price)   AS starting_price,
        COUNT(r.room_id)    AS total_rooms,
        MAX(r.capacity)     AS max_capacity,
        SUM(r.available)    AS available_rooms
    FROM Hotel h
    LEFT JOIN Room r ON r.hotel_id = h.hotel_id
    WHERE 1=1
";

// Filter: hotel name
if ($search_name !== '') {
    $sql .= " AND h.hotel_name LIKE ?";
    $params[] = '%' . $search_name . '%';
    $types   .= 's';
}

// Filter: city
if ($search_city !== '') {
    $sql .= " AND h.hotel_city LIKE ?";
    $params[] = '%' . $search_city . '%';
    $types   .= 's';
}

// Filter: guests — hotel must have at least one room with enough capacity
if ($search_guests > 0) {
    $sql .= " AND h.hotel_id IN (
                SELECT hotel_id FROM Room
                WHERE capacity >= ? AND available = 1
              )";
    $params[] = $search_guests;
    $types   .= 'i';
}

// Filter: availability for date range — exclude rooms already booked
if ($search_checkin !== '' && $search_checkout !== '') {
    $sql .= " AND r.room_id NOT IN (
                SELECT b.room_id FROM Booking b
                WHERE b.status != 'cancelled'
                  AND b.check_in  < ?
                  AND b.check_out > ?
              )";
    $params[] = $search_checkout;
    $params[] = $search_checkin;
    $types   .= 'ss';
}

$sql .= " GROUP BY h.hotel_id
          ORDER BY starting_price ASC";

// - EXECUTE -
$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
$hotels = $result->fetch_all(MYSQLI_ASSOC);
$hotel_count = count($hotels);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hotels — StayEase</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --gold: #C9A96E; --gold-light: #E8D5B0; --gold-dark: #8B6914;
    --navy: #0D1B2A; --navy-mid: #1A2E42; --navy-soft: #243447;
    --cream: #FAF7F2; --cream-mid: #F0EBE1;
    --text-dark: #0D1B2A; --text-mid: #4A5568; --text-light: #8A9BA8;
    --white: #FFFFFF; --shadow-soft: 0 4px 24px rgba(13,27,42,0.08);
    --radius: 4px; --radius-lg: 16px;
  }
  body { font-family: 'DM Sans', sans-serif; background: var(--cream); color: var(--text-dark); }

  /* NAV */
  nav {
    position: sticky; top: 0; z-index: 100;
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 60px; height: 72px;
    background: rgba(13,27,42,0.97); backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(201,169,110,0.2);
  }
  .nav-logo { font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 500; color: var(--gold); text-decoration: none; }
  .nav-logo span { color: var(--white); }
  .nav-links { display: flex; gap: 36px; list-style: none; }
  .nav-links a { color: rgba(255,255,255,0.7); text-decoration: none; font-size: 14px; transition: color 0.2s; }
  .nav-links a:hover, .nav-links a.active { color: var(--gold); }
  .nav-right { display: flex; gap: 12px; }
  .btn-ghost { padding: 8px 20px; border: 1px solid rgba(201,169,110,0.5); color: var(--gold); background: transparent; border-radius: var(--radius); font-family: 'DM Sans', sans-serif; font-size: 14px; cursor: pointer; text-decoration: none; display: inline-block; }
  .btn-gold  { padding: 8px 20px; background: var(--gold); color: var(--navy); border: none; border-radius: var(--radius); font-family: 'DM Sans', sans-serif; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; display: inline-block; }

  /* PAGE HEADER */
  .page-header {
    background: var(--navy);
    padding: 56px 60px 0;
    border-bottom: 1px solid rgba(201,169,110,0.15);
  }
  .breadcrumb { font-size: 13px; color: rgba(255,255,255,0.4); margin-bottom: 16px; }
  .breadcrumb a { color: var(--gold); text-decoration: none; }
  .page-header h1 { font-family: 'Cormorant Garamond', serif; font-size: 52px; font-weight: 300; color: var(--white); margin-bottom: 8px; }
  .page-header > p { font-size: 15px; color: rgba(255,255,255,0.5); margin-bottom: 40px; }

  /* SEARCH BAR */
  .search-bar-wrapper {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(201,169,110,0.2);
    border-bottom: none;
    border-radius: 16px 16px 0 0;
    padding: 24px 28px;
    display: flex;
    gap: 0;
    align-items: stretch;
  }
  .search-field {
    flex: 1; display: flex; flex-direction: column; gap: 5px;
    padding: 0 24px;
    border-right: 1px solid rgba(201,169,110,0.15);
    position: relative;
  }
  .search-field:first-child { padding-left: 0; }
  .search-field:last-of-type { border-right: none; }
  .search-field label { font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: var(--gold); font-weight: 500; }
  .search-field input {
    background: transparent; border: none; outline: none;
    font-family: 'DM Sans', sans-serif; font-size: 15px; color: var(--white); padding: 0;
  }
  .search-field input::placeholder { color: rgba(255,255,255,0.35); font-size: 14px; }
  .search-field input[type="date"] { color-scheme: dark; cursor: pointer; }
  .search-field input[type="number"] { -moz-appearance: textfield; }
  .search-field input[type="number"]::-webkit-inner-spin-button { -webkit-appearance: none; }
  .search-btn {
    margin-left: 20px; padding: 0 32px; background: var(--gold); color: var(--navy);
    border: none; border-radius: 10px; font-family: 'DM Sans', sans-serif;
    font-size: 14px; font-weight: 500; cursor: pointer; white-space: nowrap;
    transition: background 0.2s, transform 0.1s;
    display: flex; align-items: center; gap: 8px; flex-shrink: 0;
  }
  .search-btn:hover { background: var(--gold-light); transform: translateY(-1px); }

  /* MAIN CONTENT */
  .hotels-content { padding: 40px 60px; }
  .results-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; }
  .results-count { font-size: 15px; color: var(--text-mid); }
  .results-count strong { color: var(--text-dark); }
  .sort-select {
    padding: 8px 16px; background: var(--white); border: 1px solid var(--cream-mid);
    border-radius: var(--radius); font-family: 'DM Sans', sans-serif; font-size: 13px; color: var(--text-dark); cursor: pointer;
  }

  /* NO RESULTS */
  .no-results {
    text-align: center; padding: 80px 20px; color: var(--text-light);
  }
  .no-results h3 { font-family: 'Cormorant Garamond', serif; font-size: 28px; color: var(--text-mid); margin-bottom: 8px; }

  /* HOTEL GRID — vertical cards via CSS Grid */
  .hotel-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 28px;
  }

  /* CARD */
  .hotel-card {
    background: var(--white); border-radius: var(--radius-lg); overflow: hidden;
    box-shadow: var(--shadow-soft); cursor: pointer; text-decoration: none; color: inherit;
    display: flex; flex-direction: column; position: relative;
    transition: transform 0.25s ease, box-shadow 0.25s ease;
  }
  .hotel-card:hover { transform: translateY(-6px); box-shadow: 0 16px 48px rgba(13,27,42,0.15); }

  .card-img { width: 100%; height: 220px; overflow: hidden; flex-shrink: 0; }
  .card-img img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform 0.4s ease; }
  .hotel-card:hover .card-img img { transform: scale(1.06); }

  /* fallback when no image */
  .card-img-placeholder {
    width: 100%; height: 220px; flex-shrink: 0;
    background: var(--navy-soft);
    display: flex; align-items: center; justify-content: center;
    font-family: 'Cormorant Garamond', serif; font-size: 18px; color: var(--gold-light);
  }

  .card-body {
    padding: 20px 22px 22px; display: flex; flex-direction: column; flex: 1; gap: 10px;
  }
  .card-type { font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: var(--gold); font-weight: 500; }
  .card-name { font-family: 'Cormorant Garamond', serif; font-size: 22px; font-weight: 500; color: var(--text-dark); line-height: 1.2; }
  .card-location { font-size: 12px; color: var(--text-light); }
  .card-desc {
    font-size: 13px; color: var(--text-mid); line-height: 1.6;
    display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
  }
  .card-meta { display: flex; gap: 14px; font-size: 12px; color: var(--text-light); flex-wrap: wrap; margin-top: 2px; }
  .card-rating { display: flex; align-items: center; gap: 4px; }
  .stars { color: var(--gold); font-size: 12px; letter-spacing: 1px; }

  .card-footer {
    margin-top: auto; display: flex; justify-content: space-between; align-items: flex-end;
    padding-top: 14px; border-top: 1px solid var(--cream-mid);
  }
  .card-price-label { font-size: 11px; color: var(--text-light); margin-bottom: 2px; }
  .card-price { font-family: 'Cormorant Garamond', serif; font-size: 28px; font-weight: 500; color: var(--text-dark); line-height: 1; }
  .card-price-sub { font-size: 11px; color: var(--text-light); margin-top: 2px; }
  .card-cta {
    font-size: 12px; color: var(--gold); font-weight: 500;
    display: flex; align-items: center; gap: 5px;
    opacity: 0; transform: translateX(-4px);
    transition: opacity 0.2s, transform 0.2s;
  }
  .hotel-card:hover .card-cta { opacity: 1; transform: translateX(0); }

  /* PAGINATION */
  .pagination {
    display: flex; justify-content: center; align-items: center;
    gap: 8px; margin-top: 48px; padding-top: 32px; border-top: 1px solid var(--cream-mid);
  }
  .page-btn {
    width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;
    background: var(--white); border: 1px solid var(--cream-mid); border-radius: var(--radius);
    font-size: 14px; color: var(--text-mid); cursor: pointer; transition: all 0.2s; text-decoration: none;
  }
  .page-btn:hover, .page-btn.active { background: var(--navy); color: var(--gold); border-color: var(--navy); }

  @media (max-width: 900px) {
    nav { padding: 0 20px; }
    .page-header { padding: 40px 20px 0; }
    .page-header h1 { font-size: 36px; }
    .search-bar-wrapper { flex-direction: column; gap: 16px; padding: 20px; }
    .search-field { border-right: none; border-bottom: 1px solid rgba(201,169,110,0.15); padding: 0 0 16px 0; }
    .search-field:last-of-type { border-bottom: none; padding-bottom: 0; }
    .search-btn { margin-left: 0; padding: 14px; justify-content: center; border-radius: 8px; }
    .hotels-content { padding: 28px 20px; }
    .hotel-grid { grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 20px; }
  }
  @media (max-width: 520px) {
    .hotel-grid { grid-template-columns: 1fr; }
  }
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <a href="home.php" class="nav-logo">Stay<span>Ease</span></a>
  <ul class="nav-links">
    <li><a href="hotels.php" class="active">Hotels</a></li>
    <li><a href="home.php">Amenities</a></li>
    <li><a href="home.php#about">About</a></li>
    <li><a href="home.php#contact">Contact</a></li>
  </ul>
  <div class="nav-right">
    <?php if (isset($_SESSION['user_id'])): ?>
          <span style="color:rgba(255,255,255,0.6);font-size:13px;">Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Guest') ?></span>
          <a href="logout.php" class="btn-ghost">Sign Out</a>
        <?php else: ?>
          <a href="login.php" class="btn-ghost">Sign In</a>
          <a href="register.php" class="btn-gold">Register</a>
        <?php endif; ?>
   
  </div>
</nav>

<!-- PAGE HEADER + SEARCH -->
<div class="page-header">
  <div class="breadcrumb"><a href="home.php">Home</a> / Hotels</div>
  <h1>Find Your Perfect Hotel</h1>
  <p>Browse our curated collection of world-class properties.</p>

  <!-- SEARCH FORM — GET so values persist in URL after submit -->
  <form method="GET" action="hotels.php" class="search-bar-wrapper" id="searchForm">
    <div class="search-field">
      <label for="q-hotel">Hotel Name</label>
      <input type="text" id="q-hotel" name="hotel"
             placeholder="e.g. Grand Horizon…"
             value="<?= htmlspecialchars($search_name) ?>"
             autocomplete="off">
    </div>
    <div class="search-field">
      <label for="q-city">City</label>
      <input type="text" id="q-city" name="city"
             placeholder="e.g. Cairo…"
             value="<?= htmlspecialchars($search_city) ?>">
    </div>
    <div class="search-field">
      <label for="q-checkin">Check-in</label>
      <input type="date" id="q-checkin" name="checkin"
             value="<?= htmlspecialchars($search_checkin) ?>">
    </div>
    <div class="search-field">
      <label for="q-checkout">Check-out</label>
      <input type="date" id="q-checkout" name="checkout"
             value="<?= htmlspecialchars($search_checkout) ?>">
    </div>
    <div class="search-field">
      <label for="q-guests">Guests</label>
      <input type="number" id="q-guests" name="guests"
             placeholder="2" min="1" max="20"
             value="<?= $search_guests > 0 ? $search_guests : '' ?>">
    </div>
    <button type="submit" class="search-btn">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
      Search
    </button>
  </form>
</div>

<!-- HOTELS CONTENT -->
<div class="hotels-content">
  <div class="results-header">
    <div class="results-count">
      <?php if ($search_name || $search_city || $search_checkin || $search_guests > 0): ?>
        Showing <strong><?= $hotel_count ?> result<?= $hotel_count !== 1 ? 's' : '' ?></strong> for your search
      <?php else: ?>
        Showing <strong><?= $hotel_count ?> hotel<?= $hotel_count !== 1 ? 's' : '' ?></strong>
      <?php endif; ?>
    </div>
    <select class="sort-select" onchange="sortHotels(this.value)">
      <option value="price_asc">Sort: Price Low to High</option>
      <option value="price_desc">Sort: Price High to Low</option>
      <option value="rating">Sort: Highest Rated</option>
    </select>
  </div>

  <?php if ($hotel_count === 0): ?>
    <!-- NO RESULTS STATE -->
    <div class="no-results">
      <h3>No hotels found</h3>
      <p>Try adjusting your search — different dates, city, or fewer guests.</p>
    </div>

  <?php else: ?>
    <div class="hotel-grid">

      <?php foreach ($hotels as $hotel): ?>
        <?php
          // Build star string based on rating
          $rating     = floatval($hotel['hotel_rating']);
          $full_stars = floor($rating);
          $stars_html = str_repeat('★', $full_stars) . str_repeat('☆', 5 - $full_stars);

          // Format starting price
          $price_formatted = $hotel['starting_price']
            ? 'EGP ' . number_format($hotel['starting_price'], 0)
            : 'On request';

          // Pass search params forward to rooms page so dates/guests carry over
          $rooms_url = 'rooms.php?hotel_id=' . $hotel['hotel_id']
            . '&checkin='  . urlencode($search_checkin)
            . '&checkout=' . urlencode($search_checkout)
            . '&guests='   . $search_guests;
        ?>

        <div class="hotel-card" data-href="<?= $rooms_url ?>">

          <!-- IMAGE -->
          <?php if (!empty($hotel['hotel_image'])): ?>
            <div class="card-img">
              <img src="<?= htmlspecialchars($hotel['hotel_image']) ?>"
                   alt="<?= htmlspecialchars($hotel['hotel_name']) ?>">
            </div>
          <?php else: ?>
            <div class="card-img-placeholder">
              <?= htmlspecialchars($hotel['hotel_name']) ?>
            </div>
          <?php endif; ?>

          <!-- BODY -->
          <div class="card-body">

            <!-- Type row: available rooms count -->
            <div class="card-type">
              <?= intval($hotel['available_rooms']) ?> room<?= $hotel['available_rooms'] != 1 ? 's' : '' ?> available
            </div>

            <!-- Hotel name -->
            <div class="card-name"><?= htmlspecialchars($hotel['hotel_name']) ?></div>

            <!-- City + address -->
            <div class="card-location">
              <?= htmlspecialchars($hotel['hotel_city']) ?>
              &mdash; <?= htmlspecialchars($hotel['hotel_address']) ?>
            </div>

            <!-- hotel_details attribute used here -->
            <div class="card-desc">
              <?= htmlspecialchars($hotel['hotel_details']) ?>
            </div>

            <!-- Meta row: capacity + rating -->
            <div class="card-meta">
              <span>Up to <?= intval($hotel['max_capacity']) ?> guests</span>
              <span class="card-rating">
                <span class="stars"><?= $stars_html ?></span>
                <?= number_format($rating, 1) ?>
              </span>
            </div>

            <!-- Footer: starting price (MIN room price from query) -->
            <div class="card-footer">
              <div>
                <div class="card-price-label">starting from</div>
                <div class="card-price"><?= $price_formatted ?></div>
                <div class="card-price-sub">per night</div>
              </div>
              <div class="card-cta">View Rooms &rarr;</div>
            </div>

            <a href="booking.php?hotel_id=<?= $hotel['hotel_id'] ?>" class="hotels-book-btn">Book Now</a>

          </div>
        </div>

      <?php endforeach; ?>

    </div>
  <?php endif; ?>

</div><!-- /hotels-content -->

<script>
  document.querySelectorAll('.hotel-card[data-href]').forEach(card => {
    card.addEventListener('click', function(e) {
      if (!e.target.closest('.hotels-book-btn')) {
        window.location.href = this.dataset.href;
      }
    });
  });

  // Keep checkout min = checkin value
  const today = new Date().toISOString().split('T')[0];
  const ci = document.getElementById('q-checkin');
  const co = document.getElementById('q-checkout');
  if (ci) ci.min = today;
  if (co) co.min = today;
  if (ci) ci.addEventListener('change', () => { if (co) co.min = ci.value || today; });

  // Client-side sort (re-submits with sort param — you can wire this to PHP ORDER BY later)
  function sortHotels(val) {
    const url = new URL(window.location.href);
    url.searchParams.set('sort', val);
    window.location.href = url.toString();
  }
</script>

</body>
</html>
