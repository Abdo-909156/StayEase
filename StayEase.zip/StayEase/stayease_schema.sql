-- ============================================================
--  StayEase Database Schema
--  Import this ONCE via phpMyAdmin > Import
-- ============================================================

CREATE DATABASE IF NOT EXISTS stayease CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE stayease;

-- ── USERS ────────────────────────────────────────────────────
CREATE TABLE User (
    user_id   INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100)        NOT NULL,
    username  VARCHAR(50)         NOT NULL UNIQUE,
    password  VARCHAR(255)        NOT NULL,   -- store hashed (password_hash)
    DOB       DATE,
    created_at DATETIME           DEFAULT CURRENT_TIMESTAMP
);

-- ── HOTELS ───────────────────────────────────────────────────
CREATE TABLE Hotel (
    hotel_id      INT AUTO_INCREMENT PRIMARY KEY,
    hotel_name    VARCHAR(150)    NOT NULL,
    hotel_address VARCHAR(255)    NOT NULL,
    hotel_city    VARCHAR(100)    NOT NULL,
    hotel_details TEXT,                       -- long description shown on card
    hotel_rating  DECIMAL(2,1)   DEFAULT 0.0  CHECK (hotel_rating BETWEEN 0 AND 5),
    hotel_image   VARCHAR(255),               -- relative path e.g. images/hotel1.jpg
    created_at    DATETIME        DEFAULT CURRENT_TIMESTAMP
);

-- ── ROOMS ────────────────────────────────────────────────────
CREATE TABLE Room (
    room_id      INT AUTO_INCREMENT PRIMARY KEY,
    hotel_id     INT             NOT NULL,
    room_number  VARCHAR(20)     NOT NULL,
    room_details TEXT,                        -- description shown on room card
    room_price   DECIMAL(10,2)   NOT NULL,
    room_rating  DECIMAL(2,1)    DEFAULT 0.0  CHECK (room_rating BETWEEN 0 AND 5),
    capacity     INT             NOT NULL,
    area         DECIMAL(6,2),               -- in m²
    available    TINYINT(1)      DEFAULT 1,  -- 1 = available, 0 = not
    FOREIGN KEY (hotel_id) REFERENCES Hotel(hotel_id) ON DELETE CASCADE
);

-- ── BOOKINGS ─────────────────────────────────────────────────
CREATE TABLE Booking (
    booking_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT             NOT NULL,
    room_id       INT             NOT NULL,
    booking_date  DATETIME        DEFAULT CURRENT_TIMESTAMP,
    check_in      DATE            NOT NULL,
    check_out     DATE            NOT NULL,
    booking_price DECIMAL(10,2)   NOT NULL,
    status        ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES User(user_id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES Room(room_id) ON DELETE CASCADE
);

-- ── SAMPLE DATA ──────────────────────────────────────────────
INSERT INTO Hotel (hotel_name, hotel_address, hotel_city, hotel_details, hotel_rating, hotel_image) VALUES
('Grand Horizon Hotel',   '15 Nile Corniche, Downtown',   'Cairo',       'A landmark property overlooking the Nile with floor-to-ceiling windows, marble interiors, and world-class dining.',              4.8, 'images/Azure.jpeg'),
('Azure Oceanfront Hotel','1 Marina Boulevard, Montazah', 'Alexandria',  'Seafront luxury hotel with private beach access, panoramic Mediterranean views, and a full-service spa.',                       4.7, 'images/deluxe-1_1920x960.webp'),
('Garden Retreat Hotel',  '22 Garden City Street',        'Cairo',       'A tranquil urban escape tucked inside lush gardens. Ideal for travelers seeking calm without leaving the city centre.',          4.3, 'images/GrandHorizon.jpg'),
('The Imperial Penthouse','1 Conrad Tower, Zamalek',      'Cairo',       'Our crown jewel. Two floors of pure luxury with a private chef, butler service, rooftop pool, and 360-degree city views.',     5.0, 'images/wi-mlawi-penthouse-terrace-19551_Classic-Hor.jpeg');

INSERT INTO Room (hotel_id, room_number, room_details, room_price, room_rating, capacity, area, available) VALUES
(1, '101', 'King-sized bed, marble bathroom, city view, mini bar, and complimentary breakfast.',          11800.00, 4.7, 2, 45.00, 1),
(1, '102', 'Twin beds, garden-facing balcony, rainfall shower, and 55-inch smart TV.',                    9500.00,  4.5, 2, 38.00, 1),
(2, '201', 'King bed, private terrace with sea view, jacuzzi, and separate living area.',                 20600.00, 4.9, 3, 72.00, 1),
(2, '202', 'Double bed, ocean-facing window, espresso bar, and luxury bath amenities.',                   15200.00, 4.6, 2, 50.00, 1),
(3, '301', 'Queen bed, garden view, cozy reading nook, blackout curtains, and smart controls.',            5900.00, 4.3, 2, 30.00, 1),
(4, 'PH1', '3-bedroom penthouse with private pool, chef kitchen, butler service, and panoramic views.',  48100.00, 5.0, 6, 160.00, 1);
