<?php
session_start();
require_once 'config.php';

// Expect ?hotel_id=X in the URL
$hotel_id = intval($_GET['hotel_id'] ?? 0);

if (!$hotel_id) {
    header('Location: hotels.php');
    exit;
}

// Fetch hotel info
$hStmt = $conn->prepare("SELECT hotel_name, hotel_address, hotel_city, hotel_details, hotel_rating, hotel_image FROM Hotel WHERE hotel_id = ?");
$hStmt->bind_param("i", $hotel_id);
$hStmt->execute();
$hStmt->bind_result($hotel_name, $hotel_address, $hotel_city, $hotel_details, $hotel_rating, $hotel_image);
if (!$hStmt->fetch()) {
    header('Location: hotels.php');
    exit;
}
$hStmt->close();

// Fetch all rooms for this hotel
$rooms = [];
$rStmt = $conn->prepare("SELECT room_id, room_number, room_details, room_price, room_rating, capacity, area, available FROM Room WHERE hotel_id = ? ORDER BY room_number");
$rStmt->bind_param("i", $hotel_id);
$rStmt->execute();
$result = $rStmt->get_result();
while ($row = $result->fetch_assoc()) {
    $rooms[] = $row;
}
$rStmt->close();

// Format star rating as stars
function stars($rating) {
    $full  = floor($rating);
    $half  = ($rating - $full) >= 0.5 ? 1 : 0;
    $empty = 5 - $full - $half;
    return str_repeat('★', $full) . str_repeat('½', $half) . str_repeat('☆', $empty);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($hotel_name) ?> — Rooms — StayEase</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --gold: #C9A96E; --gold-light: #E8D5B0; --gold-dark: #8B6914;
    --navy: #0D1B2A; --navy-mid: #1A2E42; --navy-soft: #243447;
    --cream: #FAF7F2; --cream-mid: #F0EBE1;
    --text-dark: #0D1B2A; --text-mid: #4A5568; --text-light: #8A9BA8;
    --white: #FFFFFF;
    --radius: 4px;
  }
  body { font-family: 'DM Sans', sans-serif; background: var(--cream); color: var(--text-dark); }

  nav {
    position: sticky; top: 0; z-index: 100;
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 60px; height: 72px;
    background: rgba(13,27,42,0.97); backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(201,169,110,0.2);
  }
  .nav-logo { font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 500; color: var(--gold); text-decoration: none; }
  .nav-logo span { color: var(--white); }
  .nav-links { display: flex; gap: 36px; list-style: none; }
  .nav-links a { color: rgba(255,255,255,0.7); text-decoration: none; font-size: 14px; transition: color 0.2s; }
  .nav-links a:hover { color: var(--gold); }
  .nav-right { display: flex; gap: 12px; align-items: center; }
  .btn-ghost { padding: 8px 20px; border: 1px solid rgba(201,169,110,0.5); color: var(--gold); background: transparent; border-radius: var(--radius); font-size: 14px; cursor: pointer; text-decoration: none; display: inline-block; }
  .btn-gold  { padding: 8px 20px; background: var(--gold); color: var(--navy); border: none; border-radius: var(--radius); font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; display: inline-block; }
  .nav-user  { font-size: 13px; color: var(--gold-light); }

  /* HERO */
  .hero { width: 100%; height: 360px; position: relative; overflow: hidden; background: var(--navy-mid); }
  .hero img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .hero-overlay { position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(13,27,42,0.3), rgba(13,27,42,0.7)); }
  .hero-content { position: absolute; bottom: 40px; left: 60px; z-index: 2; }
  .back-btn {
    position: absolute; top: 24px; left: 24px; z-index: 3;
    background: rgba(13,27,42,0.7); backdrop-filter: blur(8px);
    border: 1px solid rgba(201,169,110,0.3);
    color: var(--white); padding: 8px 16px; border-radius: var(--radius);
    font-size: 13px; text-decoration: none; transition: background 0.2s;
  }
  .back-btn:hover { background: rgba(13,27,42,0.95); }
  .hero-hotel-name { font-family: 'Cormorant Garamond', serif; font-size: 42px; font-weight: 300; color: var(--white); line-height: 1.1; margin-bottom: 6px; }
  .hero-hotel-loc  { font-size: 14px; color: rgba(255,255,255,0.6); }
  .hero-rating { margin-top: 10px; color: var(--gold); font-size: 18px; letter-spacing: 2px; }

  /* ROOMS SECTION */
  .rooms-section { max-width: 1100px; margin: 0 auto; padding: 64px 24px 80px; }
  .section-label { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: var(--gold); margin-bottom: 8px; }
  .section-title { font-family: 'Cormorant Garamond', serif; font-size: 38px; font-weight: 300; color: var(--text-dark); margin-bottom: 48px; }

  /* ROOM CARD */
  .room-card {
    display: grid; grid-template-columns: 1fr 1fr;
    background: var(--white); border-radius: var(--radius);
    overflow: hidden; margin-bottom: 32px;
    box-shadow: 0 4px 24px rgba(13,27,42,0.08);
    transition: box-shadow 0.2s;
  }
  .room-card:hover { box-shadow: 0 8px 40px rgba(13,27,42,0.14); }
  .room-card.unavailable { opacity: 0.6; }

  .room-card-image { position: relative; min-height: 260px; background: var(--navy-soft); overflow: hidden; }
  .room-card-image img { width: 100%; height: 100%; object-fit: cover; display: block; }
  .room-number-badge {
    position: absolute; top: 16px; left: 16px;
    background: rgba(13,27,42,0.8); backdrop-filter: blur(6px);
    border: 1px solid rgba(201,169,110,0.3);
    color: var(--gold); font-size: 12px; padding: 4px 12px; border-radius: var(--radius);
  }
  .unavail-badge {
    position: absolute; top: 16px; right: 16px;
    background: rgba(192,57,43,0.85);
    color: #fff; font-size: 11px; padding: 4px 10px; border-radius: var(--radius);
  }

  .room-card-body { padding: 36px 40px; display: flex; flex-direction: column; justify-content: space-between; }
  .room-card-top {}
  .room-title { font-family: 'Cormorant Garamond', serif; font-size: 28px; font-weight: 400; color: var(--text-dark); margin-bottom: 6px; }
  .room-rating { font-size: 14px; color: var(--gold); margin-bottom: 16px; letter-spacing: 1px; }
  .room-desc { font-size: 14px; color: var(--text-mid); line-height: 1.8; margin-bottom: 24px; }

  .room-meta { display: flex; gap: 24px; margin-bottom: 28px; flex-wrap: wrap; }
  .meta-item { display: flex; flex-direction: column; }
  .meta-label { font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase; color: var(--text-light); margin-bottom: 2px; }
  .meta-value { font-size: 14px; font-weight: 500; color: var(--text-dark); }

  .room-card-footer { display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--cream-mid); padding-top: 20px; }
  .room-price { font-family: 'Cormorant Garamond', serif; font-size: 26px; color: var(--text-dark); }
  .room-price span { font-size: 13px; font-family: 'DM Sans', sans-serif; color: var(--text-light); }
  .btn-book {
    display: inline-block; padding: 12px 32px;
    background: var(--navy); color: var(--gold);
    border: none; border-radius: var(--radius);
    font-family: 'DM Sans', sans-serif; font-size: 14px; font-weight: 500;
    cursor: pointer; text-decoration: none; transition: background 0.2s;
  }
  .btn-book:hover { background: var(--navy-soft); }
  .btn-book.disabled { background: var(--cream-mid); color: var(--text-light); cursor: not-allowed; pointer-events: none; }

  .no-rooms { text-align: center; padding: 80px 24px; color: var(--text-light); font-size: 16px; }

  @media (max-width: 768px) {
    nav { padding: 0 20px; }
    .hero { height: 240px; }
    .hero-content { left: 20px; bottom: 24px; }
    .hero-hotel-name { font-size: 28px; }
    .room-card { grid-template-columns: 1fr; }
    .room-card-image { min-height: 200px; }
    .room-card-body { padding: 24px; }
    .nav-links { display: none; }
  }
</style>
</head>
<body>

<nav>
  <a href="home.php" class="nav-logo">Stay<span>Ease</span></a>
  <ul class="nav-links">
    <li><a href="hotels.php" style="color: var(--gold);">Hotels</a></li>
  </ul>
  <div class="nav-right">
    <?php if (isset($_SESSION['user_id'])): ?>
      <span class="nav-user">Hello, <?= htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]) ?></span>
      <a href="logout.php" class="btn-ghost">Sign Out</a>
    <?php else: ?>
      <a href="login.php" class="btn-ghost">Sign In</a>
      <a href="register.php" class="btn-gold">Register</a>
    <?php endif; ?>
  </div>
</nav>

<!-- HERO -->
<div class="hero">
  <a href="hotels.php" class="back-btn">← Back to Hotels</a>
  <?php if ($hotel_image): ?>
    <img src="<?= htmlspecialchars($hotel_image) ?>" alt="<?= htmlspecialchars($hotel_name) ?>">
  <?php endif; ?>
  <div class="hero-overlay"></div>
  <div class="hero-content">
    <h1 class="hero-hotel-name"><?= htmlspecialchars($hotel_name) ?></h1>
    <p class="hero-hotel-loc"><?= htmlspecialchars($hotel_address) ?>, <?= htmlspecialchars($hotel_city) ?></p>
    <div class="hero-rating"><?= stars($hotel_rating) ?> <span style="font-family:'DM Sans',sans-serif;font-size:13px;color:rgba(255,255,255,0.6);margin-left:8px;"><?= number_format($hotel_rating, 1) ?> / 5</span></div>
  </div>
</div>

<!-- ROOMS -->
<div class="rooms-section">
  <div class="section-label">Available Accommodations</div>
  <h2 class="section-title">Rooms at <?= htmlspecialchars($hotel_name) ?></h2>

  <?php if (empty($rooms)): ?>
    <div class="no-rooms">No rooms found for this hotel.</div>
  <?php else: ?>
    <?php foreach ($rooms as $room): ?>
      <?php $avail = (bool)$room['available']; ?>
      <div class="room-card<?= $avail ? '' : ' unavailable' ?>">

        <!-- IMAGE PLACEHOLDER (swap src to a real path if you have per-room images) -->
        <div class="room-card-image">
          <img src="<?= htmlspecialchars($hotel_image ?: '') ?>" alt="Room <?= htmlspecialchars($room['room_number']) ?>">
          <div class="room-number-badge">Room <?= htmlspecialchars($room['room_number']) ?></div>
          <?php if (!$avail): ?>
            <div class="unavail-badge">Unavailable</div>
          <?php endif; ?>
        </div>

        <!-- BODY -->
        <div class="room-card-body">
          <div class="room-card-top">
            <h3 class="room-title">Room <?= htmlspecialchars($room['room_number']) ?></h3>
            <div class="room-rating"><?= stars($room['room_rating']) ?> <?= number_format($room['room_rating'], 1) ?></div>
            <p class="room-desc"><?= nl2br(htmlspecialchars($room['room_details'] ?? '')) ?></p>
            <div class="room-meta">
              <div class="meta-item">
                <span class="meta-label">Capacity</span>
                <span class="meta-value"><?= (int)$room['capacity'] ?> guests</span>
              </div>
              <?php if ($room['area']): ?>
              <div class="meta-item">
                <span class="meta-label">Area</span>
                <span class="meta-value"><?= number_format($room['area'], 0) ?> m²</span>
              </div>
              <?php endif; ?>
              <div class="meta-item">
                <span class="meta-label">Status</span>
                <span class="meta-value" style="color:<?= $avail ? '#2d6a4f' : '#c0392b' ?>"><?= $avail ? 'Available' : 'Booked' ?></span>
              </div>
            </div>
          </div>

          <div class="room-card-footer">
            <div class="room-price">
              EGP<?= number_format($room['room_price'], 0) ?> <span>/ night</span>
            </div>
            <?php if ($avail): ?>
              <?php if (isset($_SESSION['user_id'])): ?>
                <a href="booking.php?room_id=<?= $room['room_id'] ?>" class="btn-book">Book Now</a>
              <?php else: ?>
                <a href="login.php" class="btn-book">Sign In to Book</a>
              <?php endif; ?>
            <?php else: ?>
              <span class="btn-book disabled">Unavailable</span>
            <?php endif; ?>
          </div>
        </div>

      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

</body>
</html>
