<?php
// -- rooms.php ------------------------------------------------
require_once 'config.php';
session_start();

// -- Inputs 
$hotel_id       = (int)   ($_GET['hotel_id'] ?? 0);
$search_checkin  = trim($_GET['checkin']  ?? '');
$search_checkout = trim($_GET['checkout'] ?? '');
$search_guests   = (int)  ($_GET['guests']  ?? 0);
$sort            = trim($_GET['sort']     ?? 'price_asc');

if (!$hotel_id) {
    header('Location: hotels.php');
    exit;
}

// -- Fetch hotel details --------------------------------------
$hstmt = $conn->prepare(
    "SELECT hotel_id, hotel_name, hotel_address, hotel_city,
            hotel_details, hotel_rating, hotel_image
     FROM Hotel WHERE hotel_id = ?"
);
$hstmt->bind_param('i', $hotel_id);
$hstmt->execute();
$hotel = $hstmt->get_result()->fetch_assoc();

if (!$hotel) {
    header('Location: hotels.php');
    exit;
}

// -- Build rooms query ----------------------------------------
$params = [$hotel_id];
$types  = 'i';

$sql = "
    SELECT r.room_id, r.room_number, r.room_details,
           r.room_price, r.room_rating, r.capacity, r.area, r.available
    FROM Room r
    WHERE r.hotel_id = ?
";

// Filter: only rooms that fit guest count
if ($search_guests > 0) {
    $sql .= " AND r.capacity >= ?";
    $params[] = $search_guests;
    $types   .= 'i';
}

// Filter: exclude rooms booked in date range
if ($search_checkin !== '' && $search_checkout !== '') {
    $sql .= " AND r.room_id NOT IN (
                SELECT b.room_id FROM Booking b
                WHERE b.status != 'cancelled'
                  AND b.check_in  < ?
                  AND b.check_out > ?
              )";
    $params[] = $search_checkout;
    $params[] = $search_checkin;
    $types   .= 'ss';
}

// Sort
$order_map = [
    'price_asc'  => 'r.room_price ASC',
    'price_desc' => 'r.room_price DESC',
    'capacity'   => 'r.capacity DESC',
    'rating'     => 'r.room_rating DESC',
];
$sql .= " ORDER BY " . ($order_map[$sort] ?? 'r.room_price ASC');

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$rooms      = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$room_count = count($rooms);

// -- Star helper ----------------------------------------------
function room_stars(float $r): string {
    $f = (int) round($r);
    return str_repeat('&#9733;', $f) . str_repeat('&#9734;', 5 - $f);
}

// -- Rating label ---------------------------------------------
function rating_label(float $r): string {
    if ($r >= 4.8) return 'Exceptional';
    if ($r >= 4.5) return 'Excellent';
    if ($r >= 4.0) return 'Very Good';
    if ($r >= 3.5) return 'Good';
    return 'Standard';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($hotel['hotel_name']) ?> — Rooms &amp; Suites</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --gold: #C9A96E; --gold-light: #E8D5B0; --gold-dark: #8B6914;
  --navy: #0D1B2A; --navy-mid: #1A2E42; --navy-soft: #243447;
  --cream: #FAF7F2; --cream-mid: #F0EBE1;
  --text-dark: #0D1B2A; --text-mid: #4A5568; --text-light: #8A9BA8;
  --white: #FFFFFF;
  --shadow-soft: 0 4px 24px rgba(13,27,42,0.08);
  --radius: 4px; --radius-lg: 16px;
}

body { font-family: 'DM Sans', sans-serif; background: var(--cream); color: var(--text-dark); }
a { text-decoration: none; }
ul { list-style: none; }

/* ---- NAV ---- */
nav {
  position: sticky; top: 0; z-index: 100;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 60px; height: 72px;
  background: rgba(13,27,42,0.97); backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(201,169,110,0.2);
}
.nav-logo { font-family: 'Cormorant Garamond', serif; font-size: 26px; font-weight: 500; color: var(--gold); }
.nav-logo span { color: var(--white); }
.nav-links { display: flex; gap: 36px; }
.nav-links a { color: rgba(255,255,255,0.7); font-size: 14px; transition: color 0.2s; }
.nav-links a:hover, .nav-links a.active { color: var(--gold); }
.nav-right { display: flex; gap: 12px; align-items: center; }
.btn-ghost {
  padding: 8px 20px; border: 1px solid rgba(201,169,110,0.5);
  color: var(--gold); background: transparent; border-radius: var(--radius);
  font-size: 14px; font-family: 'DM Sans', sans-serif;
}
.btn-ghost:hover { background: rgba(201,169,110,0.1); }
.btn-gold {
  padding: 8px 20px; background: var(--gold); color: var(--navy);
  border: none; border-radius: var(--radius);
  font-size: 14px; font-weight: 500; font-family: 'DM Sans', sans-serif;
}
.btn-gold:hover { background: var(--gold-light); }

/* ---- HOTEL HERO ---- */
.hotel-hero {
  background: var(--navy);
  position: relative;
  overflow: hidden;
}
.hotel-hero-bg {
  position: absolute; inset: 0;
  background-size: cover;
  background-position: center;
  opacity: 0.2;
  transition: opacity 0.4s;
}
.hotel-hero-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(
    105deg,
    rgba(13,27,42,0.98) 0%,
    rgba(13,27,42,0.85) 50%,
    rgba(13,27,42,0.5) 100%
  );
}
.hotel-hero-inner {
  position: relative; z-index: 2;
  display: grid;
  grid-template-columns: 1fr auto;
  align-items: end;
  gap: 40px;
  padding: 52px 60px 40px;
}
.breadcrumb {
  font-size: 12px; color: rgba(255,255,255,0.35);
  margin-bottom: 20px; display: flex; align-items: center; gap: 8px;
}
.breadcrumb a { color: var(--gold); }
.breadcrumb-sep { color: rgba(255,255,255,0.2); }
.hotel-hero-tag {
  font-size: 11px; letter-spacing: 4px;
  text-transform: uppercase; color: var(--gold);
  margin-bottom: 10px;
}
.hotel-hero-name {
  font-family: 'Cormorant Garamond', serif;
  font-size: 54px; font-weight: 300;
  color: var(--white); line-height: 1.05;
  margin-bottom: 12px;
}
.hotel-hero-name em { font-style: italic; color: var(--gold); }
.hotel-hero-location {
  font-size: 14px; color: rgba(255,255,255,0.45);
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 20px;
}
.hotel-hero-location::before {
  content: '&#9702;';
  color: var(--gold); font-size: 10px;
}
.hotel-hero-meta {
  display: flex; align-items: center; gap: 20px; flex-wrap: wrap;
}
.hero-rating-stars {
  color: var(--gold); font-size: 14px; letter-spacing: 2px;
}
.hero-rating-num {
  font-family: 'Cormorant Garamond', serif;
  font-size: 20px; color: var(--white); font-weight: 400;
}
.hero-rating-label {
  font-size: 12px; color: rgba(255,255,255,0.45);
  letter-spacing: 1px; text-transform: uppercase;
}
.hero-divider {
  width: 1px; height: 28px;
  background: rgba(255,255,255,0.12);
}
.hero-stat-val {
  font-family: 'Cormorant Garamond', serif;
  font-size: 20px; color: var(--white);
}
.hero-stat-label {
  font-size: 12px; color: rgba(255,255,255,0.35);
  letter-spacing: 1px; text-transform: uppercase; margin-left: 6px;
}

/* ---- FILTER BAR ---- */
.filter-bar {
  background: var(--navy-mid);
  border-bottom: 1px solid rgba(201,169,110,0.15);
  padding: 0 60px;
  display: flex; align-items: stretch; gap: 0;
}
.filter-field {
  display: flex; flex-direction: column; gap: 4px;
  padding: 16px 24px;
  border-right: 1px solid rgba(255,255,255,0.06);
}
.filter-field:first-child { padding-left: 0; }
.filter-label {
  font-size: 10px; letter-spacing: 2px;
  text-transform: uppercase; color: var(--gold);
  font-weight: 500;
}
.filter-field input,
.filter-field select {
  background: transparent; border: none; outline: none;
  font-family: 'DM Sans', sans-serif;
  font-size: 14px; color: var(--white);
  padding: 0; cursor: pointer;
}
.filter-field input::placeholder { color: rgba(255,255,255,0.3); }
.filter-field input[type="date"] { color-scheme: dark; }
.filter-field select option { background: var(--navy-mid); color: var(--white); }
.filter-spacer { flex: 1; }
.filter-actions {
  display: flex; align-items: center; gap: 12px; padding: 12px 0 12px 24px;
}
.filter-btn {
  padding: 9px 24px; background: var(--gold); color: var(--navy);
  border: none; border-radius: var(--radius);
  font-family: 'DM Sans', sans-serif; font-size: 13px; font-weight: 500;
  cursor: pointer; transition: background 0.2s; white-space: nowrap;
}
.filter-btn:hover { background: var(--gold-light); }
.filter-clear {
  font-size: 13px; color: rgba(255,255,255,0.35);
  text-decoration: none; white-space: nowrap;
  transition: color 0.2s;
}
.filter-clear:hover { color: var(--gold); }

/* ---- MAIN CONTENT ---- */
.rooms-content { padding: 40px 60px 80px; }

.rooms-header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 32px;
}
.rooms-count {
  font-size: 14px; color: var(--text-mid);
}
.rooms-count strong { color: var(--text-dark); font-size: 16px; }

.sort-wrap { display: flex; align-items: center; gap: 10px; }
.sort-label { font-size: 12px; color: var(--text-light); letter-spacing: 1px; text-transform: uppercase; }
.sort-select {
  padding: 8px 14px; background: var(--white);
  border: 1px solid var(--cream-mid); border-radius: var(--radius);
  font-family: 'DM Sans', sans-serif; font-size: 13px;
  color: var(--text-dark); cursor: pointer;
}

/* ---- ROOMS GRID ---- */
.rooms-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 28px;
}

/* ---- ROOM CARD ---- */
.room-card {
  background: var(--white);
  border-radius: var(--radius-lg);
  overflow: hidden;
  box-shadow: var(--shadow-soft);
  display: flex; flex-direction: column;
  transition: transform 0.25s, box-shadow 0.25s;
  position: relative;
}
.room-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 16px 48px rgba(13,27,42,0.13);
}

/* Availability ribbon */
.room-ribbon {
  position: absolute; top: 16px; left: 16px; z-index: 2;
  font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase;
  padding: 4px 12px; border-radius: 2px; font-weight: 500;
}
.room-ribbon--available { background: var(--gold); color: var(--navy); }
.room-ribbon--unavailable { background: var(--navy-soft); color: rgba(255,255,255,0.6); }

/* Card image strip */
.room-img-strip {
  height: 200px;
  background: var(--navy-soft);
  overflow: hidden; flex-shrink: 0;
  position: relative;
  display: flex; align-items: center; justify-content: center;
}
.room-img-strip img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 0.4s;
}
.room-card:hover .room-img-strip img { transform: scale(1.05); }
.room-img-placeholder {
  font-family: 'Cormorant Garamond', serif;
  font-size: 42px; font-weight: 300;
  color: var(--gold); opacity: 0.5;
  letter-spacing: 4px;
}

/* Card body */
.room-body {
  padding: 22px 24px 24px;
  display: flex; flex-direction: column; flex: 1; gap: 12px;
}

.room-type {
  font-size: 10px; letter-spacing: 2px;
  text-transform: uppercase; color: var(--gold); font-weight: 500;
}

.room-name {
  font-family: 'Cormorant Garamond', serif;
  font-size: 24px; font-weight: 500;
  color: var(--text-dark); line-height: 1.15;
}

.room-desc {
  font-size: 13px; color: var(--text-mid); line-height: 1.7;
  display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical;
  overflow: hidden;
}

/* Specs row */
.room-specs {
  display: flex; gap: 0; flex-wrap: nowrap;
  border-top: 1px solid var(--cream-mid);
  border-bottom: 1px solid var(--cream-mid);
  padding: 12px 0; margin: 0;
}
.room-spec {
  flex: 1; text-align: center;
  border-right: 1px solid var(--cream-mid);
  padding: 0 8px;
}
.room-spec:last-child { border-right: none; }
.room-spec-val {
  font-family: 'Cormorant Garamond', serif;
  font-size: 20px; font-weight: 400; color: var(--text-dark);
  line-height: 1;
}
.room-spec-label {
  font-size: 10px; letter-spacing: 1px;
  text-transform: uppercase; color: var(--text-light);
  margin-top: 4px;
}

/* Rating */
.room-rating {
  display: flex; align-items: center; gap: 8px;
}
.room-stars { color: var(--gold); font-size: 12px; letter-spacing: 1.5px; }
.room-rating-label {
  font-size: 12px; color: var(--text-light);
  letter-spacing: 0.3px;
}

/* Card footer */
.room-footer {
  margin-top: auto;
  display: flex; justify-content: space-between; align-items: flex-end;
  padding-top: 14px; border-top: 1px solid var(--cream-mid);
}
.room-price-wrap {}
.room-price-label { font-size: 11px; color: var(--text-light); margin-bottom: 3px; }
.room-price {
  font-family: 'Cormorant Garamond', serif;
  font-size: 30px; font-weight: 500; color: var(--text-dark);
  line-height: 1;
}
.room-price-night {
  font-size: 11px; color: var(--text-light);
  font-family: 'DM Sans', sans-serif; margin-top: 2px;
}
.room-book-btn {
  padding: 10px 22px; background: var(--gold); color: var(--navy);
  border-radius: var(--radius); font-size: 13px; font-weight: 500;
  letter-spacing: 0.3px; transition: background 0.2s; flex-shrink: 0;
}
.room-book-btn:hover { background: var(--gold-light); }
.room-unavailable-tag {
  padding: 10px 22px; background: var(--cream-mid); color: var(--text-light);
  border-radius: var(--radius); font-size: 13px; letter-spacing: 0.3px;
}

/* ---- NO RESULTS ---- */
.no-rooms {
  text-align: center; padding: 80px 20px; color: var(--text-light);
}
.no-rooms h3 {
  font-family: 'Cormorant Garamond', serif;
  font-size: 32px; color: var(--text-mid); margin-bottom: 10px;
}
.no-rooms p { font-size: 14px; margin-bottom: 24px; }
.no-rooms a {
  display: inline-block; padding: 10px 28px;
  border: 1px solid var(--gold); color: var(--gold-dark);
  border-radius: var(--radius); font-size: 14px; transition: all 0.2s;
}
.no-rooms a:hover { background: var(--gold); color: var(--navy); }

/* ---- FOOTER ---- */
footer {
  background: var(--navy); padding: 64px 60px 32px;
  border-top: 1px solid rgba(201,169,110,0.15);
}
.footer-grid {
  display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 48px; margin-bottom: 48px;
}
.footer-logo {
  font-family: 'Cormorant Garamond', serif;
  font-size: 28px; font-weight: 500; color: var(--gold); margin-bottom: 12px;
}
.footer-tagline { font-size: 13px; color: rgba(255,255,255,0.4); line-height: 1.7; max-width: 240px; }
.footer-col-title {
  font-size: 11px; letter-spacing: 2px; text-transform: uppercase;
  color: var(--gold); margin-bottom: 20px; font-weight: 500;
}
.footer-links { display: flex; flex-direction: column; gap: 12px; }
.footer-links a { font-size: 13px; color: rgba(255,255,255,0.5); transition: color 0.2s; }
.footer-links a:hover { color: var(--gold); }
.footer-bottom {
  display: flex; justify-content: space-between; padding-top: 24px;
  border-top: 1px solid rgba(255,255,255,0.08);
  font-size: 12px; color: rgba(255,255,255,0.3);
}

@media (max-width: 900px) {
  nav, .hotel-hero-inner, .filter-bar, .rooms-content, footer { padding-left: 20px; padding-right: 20px; }
  .hotel-hero-inner { grid-template-columns: 1fr; gap: 0; }
  .hotel-hero-name { font-size: 36px; }
  .filter-bar { flex-wrap: wrap; padding-top: 4px; padding-bottom: 4px; }
  .filter-field { border-right: none; border-bottom: 1px solid rgba(255,255,255,0.06); padding: 12px 0; }
  .filter-spacer { display: none; }
  .filter-actions { padding: 12px 0; width: 100%; }
  .filter-btn { flex: 1; text-align: center; }
  .rooms-grid { grid-template-columns: 1fr; }
  .nav-links { display: none; }
  .footer-grid { grid-template-columns: 1fr; gap: 32px; }
}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <a href="home.php" class="nav-logo">Stay<span>Ease</span></a>
  <ul class="nav-links">
    <li><a href="hotels.php" class="active">Hotels</a></li>
    <li><a href="home.php#amenities">Amenities</a></li>
    <li><a href="home.php#about">About</a></li>
    <li><a href="home.php#contact">Contact</a></li>
  </ul>
  <div class="nav-right">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span style="color:rgba(255,255,255,0.6);font-size:13px;">
            Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Guest') ?>
        </span>
        <a href="logout.php" class="btn-ghost">Sign Out</a>
    <?php else: ?>
        <a href="login.php"    class="btn-ghost">Sign In</a>
        <a href="register.php" class="btn-gold">Register</a>
    <?php endif; ?>
</div>
</nav>

<!-- HOTEL HERO -->
<div class="hotel-hero">
  <?php if (!empty($hotel['hotel_image'])): ?>
    <div class="hotel-hero-bg"
         style="background-image: url('<?= htmlspecialchars($hotel['hotel_image']) ?>');"></div>
  <?php endif; ?>
  <div class="hotel-hero-overlay"></div>

  <div class="hotel-hero-inner">
    <div>
      <div class="breadcrumb">
        <a href="hotels.php">Hotels</a>
        <span class="breadcrumb-sep">/</span>
        <span><?= htmlspecialchars($hotel['hotel_name']) ?></span>
      </div>
      <p class="hotel-hero-tag">Rooms &amp; Suites</p>
      <h1 class="hotel-hero-name"><?= htmlspecialchars($hotel['hotel_name']) ?></h1>
      <p class="hotel-hero-location">
        <?= htmlspecialchars($hotel['hotel_address']) ?>,
        <?= htmlspecialchars($hotel['hotel_city']) ?>
      </p>
      <div class="hotel-hero-meta">
        <span class="hero-rating-stars">
          <?php
            $hr = (float)$hotel['hotel_rating'];
            $hf = (int) round($hr);
            for ($i = 0; $i < $hf; $i++)     echo '&#9733;';
            for ($i = $hf; $i < 5; $i++)     echo '&#9734;';
          ?>
        </span>
        <span class="hero-rating-num"><?= number_format($hr, 1) ?></span>
        <span class="hero-rating-label"><?= rating_label($hr) ?></span>
        <span class="hero-divider"></span>
        <span class="hero-stat-val"><?= $room_count ?></span>
        <span class="hero-stat-label">Room<?= $room_count != 1 ? 's' : '' ?> found</span>
      </div>
    </div>
    <!-- Book this hotel CTA -->
    <div style="flex-shrink:0;">
      <a href="booking.php?hotel_id=<?= $hotel_id ?><?= $search_checkin ? '&checkin='.urlencode($search_checkin) : '' ?><?= $search_checkout ? '&checkout='.urlencode($search_checkout) : '' ?>"
         style="display:inline-block;padding:14px 32px;background:var(--gold);color:var(--navy);
                border-radius:var(--radius);font-family:'DM Sans',sans-serif;font-size:14px;
                font-weight:500;letter-spacing:0.3px;transition:background .2s;white-space:nowrap;"
         onmouseover="this.style.background='var(--gold-light)'"
         onmouseout="this.style.background='var(--gold)'">
        Book This Hotel
      </a>
    </div>
  </div>
</div>

<!-- FILTER BAR -->
<div class="filter-bar">
  <form method="GET" style="display:contents;">
    <input type="hidden" name="hotel_id" value="<?= $hotel_id ?>">

    <div class="filter-field">
      <label class="filter-label">Check-in</label>
      <input type="date" name="checkin"
             value="<?= htmlspecialchars($search_checkin) ?>"
             min="<?= date('Y-m-d') ?>"
             placeholder="Add date">
    </div>

    <div class="filter-field">
      <label class="filter-label">Check-out</label>
      <input type="date" name="checkout"
             value="<?= htmlspecialchars($search_checkout) ?>"
             placeholder="Add date">
    </div>

    <div class="filter-field">
      <label class="filter-label">Guests</label>
      <input type="number" name="guests" min="1" max="20"
             value="<?= $search_guests > 0 ? $search_guests : '' ?>"
             placeholder="How many?">
    </div>

    <div class="filter-field">
      <label class="filter-label">Sort by</label>
      <select name="sort">
        <option value="price_asc"  <?= $sort === 'price_asc'  ? 'selected' : '' ?>>Price: Low to High</option>
        <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
        <option value="capacity"   <?= $sort === 'capacity'   ? 'selected' : '' ?>>Guest Capacity</option>
        <option value="rating"     <?= $sort === 'rating'     ? 'selected' : '' ?>>Top Rated</option>
      </select>
    </div>

    <div class="filter-spacer"></div>

    <div class="filter-actions">
      <button type="submit" class="filter-btn">Search Rooms</button>
      <a href="rooms.php?hotel_id=<?= $hotel_id ?>" class="filter-clear">Clear</a>
    </div>
  </form>
</div>

<!-- ROOMS CONTENT -->
<div class="rooms-content">

  <div class="rooms-header">
    <p class="rooms-count">
      <?php if ($room_count > 0): ?>
        Showing <strong><?= $room_count ?></strong> room<?= $room_count != 1 ? 's' : '' ?>
        <?php if ($search_checkin && $search_checkout): ?>
          &mdash;
          <?php
            $nights = (strtotime($search_checkout) - strtotime($search_checkin)) / 86400;
            $ci = date('d M', strtotime($search_checkin));
            $co = date('d M', strtotime($search_checkout));
          ?>
          <span style="color:var(--gold-dark);font-weight:500"><?= $ci ?> &rarr; <?= $co ?></span>
          (<?= (int)$nights ?> night<?= $nights != 1 ? 's' : '' ?>)
        <?php endif; ?>
      <?php else: ?>
        No rooms match your search
      <?php endif; ?>
    </p>

    <?php if ($room_count > 1): ?>
    <div class="sort-wrap">
      <span class="sort-label">Sort</span>
      <form method="GET" style="display:inline;">
        <input type="hidden" name="hotel_id" value="<?= $hotel_id ?>">
        <?php if ($search_checkin):  ?><input type="hidden" name="checkin"  value="<?= htmlspecialchars($search_checkin) ?>"><?php endif; ?>
        <?php if ($search_checkout): ?><input type="hidden" name="checkout" value="<?= htmlspecialchars($search_checkout) ?>"><?php endif; ?>
        <?php if ($search_guests):   ?><input type="hidden" name="guests"   value="<?= $search_guests ?>"><?php endif; ?>
        <select class="sort-select" name="sort" onchange="this.form.submit()">
          <option value="price_asc"  <?= $sort === 'price_asc'  ? 'selected' : '' ?>>Price: Low to High</option>
          <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
          <option value="capacity"   <?= $sort === 'capacity'   ? 'selected' : '' ?>>Guest Capacity</option>
          <option value="rating"     <?= $sort === 'rating'     ? 'selected' : '' ?>>Top Rated</option>
        </select>
      </form>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($room_count === 0): ?>
    <div class="no-rooms">
      <h3>No rooms available</h3>
      <p>Try adjusting your dates or guest count, or browse other hotels.</p>
      <a href="hotels.php">View All Hotels</a>
    </div>

  <?php else: ?>
    <div class="rooms-grid">
      <?php foreach ($rooms as $room):
        $price_fmt   = 'EGP ' . number_format($room['room_price'], 0);
        $rating      = (float) $room['room_rating'];
        $stars_html  = room_stars($rating);
        $is_avail    = (bool) $room['available'];

        // Build booking URL carrying dates if present
        $book_url = 'booking.php?hotel_id=' . $hotel_id;
        if ($search_checkin)  $book_url .= '&check_in='  . urlencode($search_checkin);
        if ($search_checkout) $book_url .= '&check_out=' . urlencode($search_checkout);

        // Calculate stay total if dates given
        $nights_total = '';
        if ($search_checkin && $search_checkout) {
          $n = (strtotime($search_checkout) - strtotime($search_checkin)) / 86400;
          if ($n > 0) {
            $total = $room['room_price'] * $n;
            $nights_total = 'EGP ' . number_format($total, 0) . ' total';
          }
        }
      ?>
      <div class="room-card">

        <!-- Ribbon -->
        <div class="room-ribbon <?= $is_avail ? 'room-ribbon--available' : 'room-ribbon--unavailable' ?>">
          <?= $is_avail ? 'Available' : 'Unavailable' ?>
        </div>

        <!-- Image strip (use hotel image as fallback since rooms have no individual images) -->
        <div class="room-img-strip">
          <?php if (!empty($hotel['hotel_image'])): ?>
            <img src="<?= htmlspecialchars($hotel['hotel_image']) ?>"
                 alt="Room <?= htmlspecialchars($room['room_number']) ?>">
          <?php else: ?>
            <div class="room-img-placeholder"><?= htmlspecialchars($room['room_number']) ?></div>
          <?php endif; ?>
        </div>

        <div class="room-body">

          <div class="room-type">Room <?= htmlspecialchars($room['room_number']) ?></div>

          <div class="room-name">
            <?php
              // Derive a friendly room name from the description or number
              $desc = $room['room_details'] ?? '';
              if (stripos($desc, 'penthouse') !== false)     echo 'Penthouse Suite';
              elseif (stripos($desc, 'king') !== false)      echo 'King Suite';
              elseif (stripos($desc, 'twin') !== false)      echo 'Twin Room';
              elseif (stripos($desc, 'double') !== false)    echo 'Deluxe Double';
              elseif (stripos($desc, 'queen') !== false)     echo 'Queen Room';
              elseif (stripos($desc, 'ocean') !== false
                   || stripos($desc, 'sea') !== false)       echo 'Ocean View Suite';
              elseif (stripos($desc, 'garden') !== false)    echo 'Garden Room';
              elseif ($room['capacity'] >= 4)                echo 'Family Suite';
              else echo 'Deluxe Room';
            ?>
          </div>

          <?php if ($desc): ?>
            <p class="room-desc"><?= htmlspecialchars($desc) ?></p>
          <?php endif; ?>

          <!-- Specs -->
          <div class="room-specs">
            <div class="room-spec">
              <div class="room-spec-val"><?= (int)$room['capacity'] ?></div>
              <div class="room-spec-label">Guest<?= $room['capacity'] > 1 ? 's' : '' ?></div>
            </div>
            <?php if ($room['area']): ?>
            <div class="room-spec">
              <div class="room-spec-val"><?= (float)$room['area'] ?></div>
              <div class="room-spec-label">m&sup2;</div>
            </div>
            <?php endif; ?>
            <?php if ($search_checkin && $search_checkout && isset($n) && $n > 0): ?>
            <div class="room-spec">
              <div class="room-spec-val"><?= (int)$n ?></div>
              <div class="room-spec-label">Night<?= $n != 1 ? 's' : '' ?></div>
            </div>
            <?php endif; ?>
          </div>

          <!-- Rating -->
          <?php if ($rating > 0): ?>
          <div class="room-rating">
            <span class="room-stars"><?= $stars_html ?></span>
            <span class="room-rating-label"><?= rating_label($rating) ?> &middot; <?= number_format($rating, 1) ?></span>
          </div>
          <?php endif; ?>

          <!-- Footer -->
          <div class="room-footer">
            <div class="room-price-wrap">
              <div class="room-price-label">Starting from</div>
              <div class="room-price"><?= $price_fmt ?></div>
              <div class="room-price-night">
                per night<?= $nights_total ? ' &middot; ' . $nights_total : '' ?>
              </div>
            </div>
            <?php if ($is_avail): ?>
              <a href="<?= $book_url ?>" class="room-book-btn">Book Now</a>
            <?php else: ?>
              <span class="room-unavailable-tag">Unavailable</span>
            <?php endif; ?>
          </div>

        </div>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

</div>

<!-- FOOTER -->
<footer id="contact">
  <div class="footer-grid">
    <div>
      <p class="footer-logo">StayEase</p>
      <p class="footer-tagline">The modern way to discover and book premium hotel accommodations worldwide.</p>
    </div>
    <div>
      <h4 class="footer-col-title">Quick Links</h4>
      <ul class="footer-links">
        <li><a href="hotels.php">All Hotels</a></li>
        <li><a href="home.php#amenities">Amenities</a></li>
        <li><a href="login.php">Sign In</a></li>
        <li><a href="register.php">Register</a></li>
      </ul>
    </div>
    <div>
      <h4 class="footer-col-title">Contact Us</h4>
      <p style="font-size:13px;color:rgba(255,255,255,0.5);">stayease@gmail.com</p>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; 2025 StayEase. All rights reserved.</p>
    <p>Built for exceptional stays.</p>
  </div>
</footer>

<script>
  // Date validation: checkout must be after checkin
  const ci = document.querySelector('input[name="checkin"]');
  const co = document.querySelector('input[name="checkout"]');
  if (ci && co) {
    ci.addEventListener('change', function () {
      if (this.value) {
        const next = new Date(this.value);
        next.setDate(next.getDate() + 1);
        co.min = next.toISOString().split('T')[0];
        if (co.value && co.value <= this.value) co.value = '';
      }
    });
  }
</script>
</body>
</html>
