<?php
/* ============================================================
   index.php — StayEase Homepage
   Requires: db.php in the same folder (defines $conn)
   
   db.php should look like this:
   -
   <?php
   $conn = new mysqli('localhost', 'root', '', 'stayease');
   if ($conn->connect_error) {
       die('DB connection failed: ' . $conn->connect_error);
   }
   $conn->set_charset('utf8mb4');
   ?>
   -
============================================================ */
require_once 'config.php';
session_start();


/* ============================================================
   QUERY 1 — TOP 3 HOTELS BY TOTAL BOOKINGS
   
   Logic:
   - JOIN Hotel → Room → Booking (LEFT JOIN keeps hotels
     with zero bookings so they still appear on the page)
   - COUNT(b.booking_id) gives total_bookings per hotel
   - ORDER BY total_bookings DESC puts most-booked first
   - LIMIT 3 gives us exactly the 3 cards we need
   
   Tables used : Hotel, Room, Booking  (exact schema names)
   Columns used: hotel_id, hotel_name, hotel_address,
                 hotel_city, hotel_details, hotel_rating,
                 hotel_image, booking_id
============================================================ */
$sql_top_hotels = "
    SELECT
        h.hotel_id,
        h.hotel_name,
        h.hotel_address,
        h.hotel_city,
        h.hotel_details,
        h.hotel_rating,
        h.hotel_image,
        COUNT(b.booking_id) AS total_bookings
    FROM Hotel h
    LEFT JOIN Room r  ON r.hotel_id  = h.hotel_id
    LEFT JOIN Booking b ON b.room_id = r.room_id
    GROUP BY
        h.hotel_id,
        h.hotel_name,
        h.hotel_address,
        h.hotel_city,
        h.hotel_details,
        h.hotel_rating,
        h.hotel_image
    ORDER BY total_bookings DESC
    LIMIT 3
";

$result_hotels = $conn->query($sql_top_hotels);
$top_hotels    = $result_hotels ? $result_hotels->fetch_all(MYSQLI_ASSOC) : [];


/* ============================================================
   QUERY 2 — HOTEL COUNT PER CITY
   
   Logic:
   - GROUP BY hotel_city counts how many Hotel rows share
     the same city value
   - Stored in $city_counts['Cairo'] = 3, etc.
   - Used in the Our Locations section cards
   
   Table used : Hotel
   Column used: hotel_city
============================================================ */
$sql_city_counts = "
    SELECT hotel_city, COUNT(*) AS hotels_count
    FROM Hotel
    GROUP BY hotel_city
";

$result_cities = $conn->query($sql_city_counts);
$city_counts   = [];

if ($result_cities) {
    while ($row = $result_cities->fetch_assoc()) {
        /* key = city name, value = count */
        $city_counts[$row['hotel_city']] = (int) $row['hotels_count'];
    }
}


/* ============================================================
   HELPER — BADGE LABEL
   Assigns a label and CSS modifier based on rank (0-indexed)
   Returns an array: ['label' => '...', 'class' => '...']
============================================================ */
function badge_for_rank(int $rank): array {
    if ($rank === 0) {
        return ['label' => 'Most Visited', 'class' => 'home-hotels_card_badge--top'];
    } elseif ($rank === 1) {
        return ['label' => 'Popular',      'class' => ''];
    } else {
        return ['label' => 'Trending',     'class' => ''];
    }
}


/* ============================================================
   HELPER — STAR STRING
   Converts a DECIMAL rating (e.g. 4.8) into filled/empty stars
   Uses ★ for filled and ☆ for empty, max 5 stars
============================================================ */
function render_stars(float $rating): string {
    $filled = (int) round($rating);          /* e.g. 4.8 → 5  */
    $empty  = 5 - $filled;
    return str_repeat('★', $filled) . str_repeat('☆', $empty);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StayEase</title>

    <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

  <style>

    * {                        /*resets everything to zero*/
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {                                   /* default style for whole page*/
      font-family: 'DM Sans', sans-serif;
      background-color: #FAF7F2;
      color: #0D1B2A;
      line-height: 1.6;
    }

     a {
      text-decoration: none;   /* remove underline in links*/
    }

    ul {
      list-style: none;        /* remove bullets*/
    }

    /* CSS variables */
    :root {
      --gold:       #C9A96E;
      --gold-light: #E8D5B0;
      --gold-dark:  #8B6914;
      --navy:       #0D1B2A;
      --navy-mid:   #1A2E42;
      --navy-soft:  #243447;
      --cream:      #FAF7F2;
      --cream-mid:  #F0EBE1;
      --text-dark:  #0D1B2A;
      --text-mid:   #4A5568;
      --text-light: #8A9BA8;
      --white:      #FFFFFF;
    }

    /*Navbar*/
    header{
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 100;
        border-bottom: 1px solid rgba(201, 169, 110, 0.2);
        background: rgba(13, 27, 42, 0.95);
        backdrop-filter: blur(12px);
    }

    nav {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 72px;
      padding: 0 60px;
    }
     /*Stay ease logo*/
    .home-logo{
        font-family: 'Cormorant Garamond', serif;
        font-size: 30px;
        font-weight: 500;
        color:var(--gold);
        letter-spacing: 2px;
    }

    .home-logo span{
      color:var(--white);
    }

    .nav-links{
      display:flex;
      gap: 36px;
    }

    .nav-links a {
      color: rgba(255, 255, 255, 0.75);
      font-size: 14px;
      letter-spacing: 0.5px;
      transition: color 0.2s;
    }

    .nav-links a:hover {
      color: var(--gold);
    }

    /*login buttoms*/
    .home-login{
      display: flex;
      gap:12px;
      align-items: center;
    }

    .home-signinBtn{
      padding: 8px 20px;
      border: 1px solid rgba(201, 169, 110, 0.5);
      color: var(--gold);
      background: transparent;
      border-radius: 4px;
      font-family: 'DM Sans', sans-serif;
      font-size: 14px;
      transition: background 0.2s;
    }

    .home-signinBtn:hover{
      background: rgba(201, 169, 110, 0.1);
    }

    .home-registerBtn {
      padding: 8px 20px;
      background: var(--gold);
      color: var(--navy);
      border: none;
      border-radius: 4px;
      font-family: 'DM Sans', sans-serif;
      font-size: 14px;
      font-weight: 500;
      transition: background 0.2s;
    }

    .home-registerBtn:hover {
      background: var(--gold-light);
    }
    
    /*hero section*/

    .hero{
      position:relative;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: var(--navy);
      overflow: hidden;
    }

    /* Background Image Layer */
    .hero-bg {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-image: url('https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1600&q=80');
      background-size: cover;
      background-position: center;
      opacity: 0.25;
    }

    /* Dark Overlay Layer */
    .hero-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(
        to bottom,
        rgba(13, 27, 42, 0.6) 0%,
        rgba(13, 27, 42, 0.85) 100%
      );
    }

    /* Content sits above both layers */
    .hero-content {
      position: relative;
      z-index: 2;
      text-align: center;
      padding: 100px 20px 0 20px;
      max-width: 900px;
    }

    /* Small Label */
    .hero-tag {
      display: inline-block;
      font-size: 11px;
      letter-spacing: 4px;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 24px;
    }

    /* Main Headline */
    .hero-title {
      font-family: 'Cormorant Garamond', serif;
      font-size: 80px;
      font-weight: 300;
      color: var(--white);
      line-height: 1.05;
      margin-bottom: 20px;
    }

    .hero-title em {
      font-style: italic;
      color: var(--gold);
    }

    /* Subtitle */
    .hero-sub {
      font-size: 16px;
      color: rgba(255, 255, 255, 0.6);
      max-width: 480px;
      margin: 0 auto 48px;
    }

    /*stats bar*/
    .stats-bar {
      display: flex;
      justify-content: center;
      gap: 48px;
      padding-top: 40px;
      border-top: 1px solid rgba(201, 169, 110, 0.2);
    }

    .stat {
      text-align: center;
    }

    .stat-num {
      font-family: 'Cormorant Garamond', serif;
      font-size: 36px;
      font-weight: 400;
      color: var(--white);
      line-height: 1;
      margin-bottom: 6px;
    }

    .stat-label {
      font-size: 12px;
      color: rgba(255, 255, 255, 0.45);
      letter-spacing: 1px;
      text-transform: uppercase;
    }


    /* ================================
   HOTELS SECTION
================================ */

#hotels {
  padding: 96px 60px;
  background-color: var(--cream);
}


/* ================================
   SECTION HEADER
================================ */

.home-hotels_header {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 48px;
}

.home-hotels_tag {
  font-size: 11px;
  letter-spacing: 4px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 12px;
}

.home-hotels_title {
  font-family: 'Cormorant Garamond', serif;
  font-size: 48px;
  font-weight: 400;
  color: var(--text-dark);
  line-height: 1.1;
  margin-bottom: 10px;
}

.home-hotels_sub {
  font-size: 15px;
  color: var(--text-mid);
  max-width: 400px;
}

/* View All Hotels link */
.home-view_hotels {
  padding: 9px 22px;
  border: 1px solid var(--text-light);
  color: var(--text-mid);
  border-radius: 4px;
  font-size: 13px;
  font-family: 'DM Sans', sans-serif;
  transition: all 0.2s;
  white-space: nowrap;
}

.home-view_hotels:hover {
  border-color: var(--gold);
  color: var(--gold-dark);
}


/* ================================
   CARDS GRID
================================ */

.home-hotels_grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 28px;
}


/* ================================
   SINGLE HOTEL CARD
================================ */

.home-hotels_card {
  background: var(--white);
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 24px rgba(13, 27, 42, 0.08);
  transition: transform 0.3s, box-shadow 0.3s;
  cursor: pointer;
}

.home-hotels_card:hover {
  transform: translateY(-6px);
  box-shadow: 0 8px 40px rgba(13, 27, 42, 0.12);
}


/* ================================
   CARD IMAGE AREA
================================ */

.home-hotels_card_img {
  width: 100%;
  height: 240px;
  background-color: var(--cream-mid);
  background-size: cover;
  background-position: center;
  position: relative;
}

/* Subtle gradient at bottom of image for legibility */
.home-hotels_card_img::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 60px;
  background: linear-gradient(to top, rgba(13,27,42,0.35), transparent);
}


/* ================================
   CARD BADGE
================================ */

.home-hotels_card_badge {
  position: absolute;
  top: 16px;
  left: 16px;
  font-size: 10px;
  letter-spacing: 1px;
  text-transform: uppercase;
  padding: 4px 12px;
  border-radius: 2px;
  background: var(--navy);
  color: var(--gold);
  z-index: 1;
}

.home-hotels_card_badge--top {
  background: var(--gold);
  color: var(--navy);
}


/* ================================
   CARD BODY
================================ */

.home-hotels_card_body {
  padding: 24px;
}

.home-hotels_card_name {
  font-family: 'Cormorant Garamond', serif;
  font-size: 22px;
  font-weight: 500;
  color: var(--text-dark);
  margin-bottom: 6px;
}

/* Location row */
.home-hotels_card_location {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: var(--gold-dark);
  margin-bottom: 14px;
  font-weight: 500;
  letter-spacing: 0.3px;
}

.home-hotels_card_location::before {
  content: '◎';
  font-size: 11px;
  color: var(--gold);
}

.home-hotels_card_desc {
  font-size: 13px;
  color: var(--text-mid);
  line-height: 1.7;
}

.home-book-btn {
  display: inline-block;
  margin-top: 16px;
  padding: 9px 22px;
  background: var(--gold);
  color: var(--navy);
  border-radius: 4px;
  font-size: 13px;
  font-weight: 500;
  font-family: 'DM Sans', sans-serif;
  letter-spacing: 0.3px;
  transition: background 0.2s;
}
.home-book-btn:hover { background: var(--gold-light); }

/* ================================
   CARD RATING ROW
================================ */

.home-hotels_card_rating {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 14px;
}

/* Stars rendered from hotel_rating value */
.home-hotels_card_stars {
  font-size: 13px;
  color: var(--gold);
  letter-spacing: 2px;
}

/* Numeric rating shown beside the stars */
.home-hotels_card_ratingNum {
  font-size: 12px;
  color: var(--text-light);
}


/* ================================
   AMENITIES SECTION
================================ */

#amenities {
  padding: 96px 60px;
  background-color: var(--navy);
}


/* ================================
   SECTION HEADER
================================ */

.home-amenities_header {
  margin-bottom: 52px;
}

.home-amenities_tag {
  font-size: 11px;
  letter-spacing: 4px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 12px;
}

.home-amenities_title {
  font-family: 'Cormorant Garamond', serif;
  font-size: 48px;
  font-weight: 400;
  color: var(--white);
  line-height: 1.1;
  margin-bottom: 10px;
}

.home-amenities_sub {
  font-size: 15px;
  color: rgba(255, 255, 255, 0.45);
  max-width: 400px;
}


/* ================================
   AMENITIES GRID
================================ */

.home-amenities_grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 2px;
}


/* ================================
   SINGLE AMENITY CARD
================================ */

.home-amenities_card {
  background-color: var(--navy-mid);
  padding: 36px 28px;
  transition: background-color 0.2s;
}

.home-amenities_card:hover {
  background-color: var(--navy-soft);
}



/* ================================
   CARD TEXT
================================ */

.home-amenities_name {
  font-family: 'Cormorant Garamond', serif;
  font-size: 22px;
  font-weight: 400;
  color: var(--white);
  margin-bottom: 10px;
}

.home-amenities_desc {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.45);
  line-height: 1.7;
}


/* ================================
   LOCATIONS SECTION
================================ */

#about {
  padding: 96px 60px;
  background-color: var(--cream-mid);
}

/* ================================
   SECTION HEADER
================================ */

.home-locations_header {
  margin-bottom: 52px;
}

.home-locations_tag {
  font-size: 11px;
  letter-spacing: 4px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 12px;
}

.home-locations_title {
  font-family: 'Cormorant Garamond', serif;
  font-size: 48px;
  font-weight: 400;
  color: var(--text-dark);
  line-height: 1.1;
  margin-bottom: 10px;
}

.home-locations_sub {
  font-size: 15px;
  color: var(--text-mid);
  max-width: 400px;
}

/* ================================
   LOCATIONS GRID
   Large card left + 2 stacked right
   + a wide bottom card
================================ */

.home-locations_grid {
  display: grid;
  grid-template-columns: 1.4fr 1fr;
  grid-template-rows: auto auto;
  gap: 16px;
}

/* The 2 right-side cards stack inside a sub-column */
.home-locations_col {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

/* A fourth wide card spans full width */
.home-locations_grid_bottom {
  grid-column: 1 / -1;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

/* ================================
   SINGLE LOCATION CARD
================================ */

.home-locations_card {
  position: relative;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
}

/* Tall left card */
.home-locations_card--tall {
  height: 420px;
}

/* Shorter right-column cards */
.home-locations_card--short {
  height: 196px;
}

/* Bottom wide cards */
.home-locations_card--wide {
  height: 180px;
}

/* ================================
   CARD BG IMAGE
================================ */

.home-locations_card_bg {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: center;
  transition: transform 0.5s ease;
}

.home-locations_card:hover .home-locations_card_bg {
  transform: scale(1.05);
}

/* Dark overlay */
.home-locations_card_overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(
    to top,
    rgba(13, 27, 42, 0.75) 0%,
    rgba(13, 27, 42, 0.15) 55%,
    transparent 100%
  );
}

/* ================================
   CARD TEXT (bottom-left)
================================ */

.home-locations_card_text {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 20px 22px;
  z-index: 2;
}

.home-locations_card_city {
  font-family: 'Cormorant Garamond', serif;
  font-size: 24px;
  font-weight: 400;
  color: var(--white);
  margin-bottom: 4px;
}

/* Smaller city name for short/wide cards */
.home-locations_card--short .home-locations_card_city,
.home-locations_card--wide .home-locations_card_city {
  font-size: 20px;
}

.home-locations_card_count {
  font-size: 12px;
  color: var(--gold);
  letter-spacing: 1px;
  text-transform: uppercase;
}


/* ================================
   FOOTER
================================ */

footer {
  background-color: var(--navy);
  padding: 64px 60px 32px;
  border-top: 1px solid rgba(201, 169, 110, 0.15);
}


/* ================================
   FOOTER GRID
================================ */

.home-footer_grid {
  display: grid;
  grid-template-columns: 2fr 1fr 1fr;
  gap: 48px;
  margin-bottom: 48px;
}


/* ================================
   BRAND COLUMN
================================ */

.home-footer_logo {
  font-family: 'Cormorant Garamond', serif;
  font-size: 28px;
  font-weight: 500;
  color: var(--gold);
  margin-bottom: 12px;
}

.home-footer_tagline {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.4);
  line-height: 1.7;
  max-width: 240px;
}


/* ================================
   LINK COLUMNS
================================ */

.home-footer_colTitle {
  font-size: 11px;
  letter-spacing: 2px;
  text-transform: uppercase;
  color: var(--gold);
  margin-bottom: 20px;
  font-weight: 500;
}

.home-footer_links {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.home-footer_links a {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.5);
  transition: color 0.2s;
}

.home-footer_links a:hover {
  color: var(--gold);
}


/* ================================
   CONTACT COLUMN
================================ */

.home-footer_contact {
  display: flex;
  align-items: center;
  gap: 10px;
}


.home-footer_contactEmail {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.5);
  line-height: 1.5;
}


/* ================================
   BOTTOM BAR
================================ */

.home-footer_bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 24px;
  border-top: 1px solid rgba(255, 255, 255, 0.08);
}

.home-footer_copyright {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.3);
}

.home-footer_credit {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.3);
}



  </style> 


</head>
<body>
    <header>
        <nav>
            <a href="home.php" class="home-logo">
                Stay<span>Ease</span>
            </a>

            <ul class="nav-links">
                <li><a href="hotels.php">Hotels</a></li>
                <li><a href="#amenities">Amenities</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>

           <div class="home-login">
    <?php if (isset($_SESSION['user_id'])): ?>
        <span style="color:rgba(255,255,255,0.6);font-size:14px;">
            Welcome, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Guest') ?>
        </span>
        <a href="logout.php" class="home-signinBtn">Sign Out</a>
    <?php else: ?>
        <a href="login.php" class="home-signinBtn">Sign In</a>
        <a href="register.php" class="home-registerBtn">Register</a>
    <?php endif; ?>
</div>

        </nav>
    </header>

    <section class="hero">
        <!-- Layer 1: Background Image -->
        <div class="hero-bg"></div>

        <!-- Layer 2: Dark Overlay -->
        <div class="hero-overlay"></div>

        <!-- Layer 3: Main Content -->
        <div class="hero-content">

            <!-- Small Label -->
            <p class="hero-tag">Luxury Redefined</p>

            <!-- Main Headline -->
            <h1 class="hero-title">
                Where Every Stay<br>
                Becomes a <em>Memory</em>
            </h1>

            <!-- Subtitle -->
            <p class="hero-sub">
                Discover curated hotels crafted for the
                discerning traveler. Book with confidence, arrive
                to perfection.
            </p>

            </div>

        </div>
    </section>
    <!-- end of section hero -->


    <!-- ================================
         MOST VISITED HOTELS SECTION
    ================================ -->
    <section id="hotels">

        <!-- Section Header -->
        <div class="home-hotels_header">

            <div class="home-hotels_headerText">
                <p class="home-hotels_tag">Most Visited</p>
                <h2 class="home-hotels_title">Top Hotels</h2>
                <p class="home-hotels_sub">
                    The world's most sought-after stays, chosen by our guests.
                </p>
            </div>

            <a href="hotels.php" class="home-view_hotels">View All Hotels →</a>

        </div>
        <!-- end of section header -->

        <!-- Hotels Cards Grid -->
        <div class="home-hotels_grid">

            <?php foreach ($top_hotels as $rank => $hotel): ?>

                <?php
                /*
                 * $rank   = loop index (0, 1, 2)
                 * $hotel  = one row from the Hotel table with:
                 *   hotel_id       INT
                 *   hotel_name     VARCHAR
                 *   hotel_address  VARCHAR  ← shown as location
                 *   hotel_city     VARCHAR  ← city of the hotel
                 *   hotel_details  TEXT     ← description paragraph
                 *   hotel_rating   DECIMAL  ← e.g. 4.8
                 *   hotel_image    VARCHAR  ← path e.g. images/hotel1.jpg
                 *   total_bookings INT      ← drives the badge rank
                 */
                $badge   = badge_for_rank($rank);
                $stars   = render_stars((float) $hotel['hotel_rating']);
                $rating  = number_format((float) $hotel['hotel_rating'], 1);

                /*
                 * hotel_image is stored as a relative path in the DB
                 * e.g. "images/Azure.jpeg"
                 * htmlspecialchars() prevents XSS if a bad value is stored
                 */
                $img_src = htmlspecialchars($hotel['hotel_image'] ?? '');
                ?>

                <div class="home-hotels_card">

                    <!-- hotel_image → background image of the card -->
                    <div class="home-hotels_card_img"
                         style="background-image: url('<?= $img_src ?>');">

                        <!--
                            total_bookings drives the rank ($rank)
                            rank 0 = Most Visited (gold badge)
                            rank 1 = Popular      (navy badge)
                            rank 2 = Trending     (navy badge)
                        -->
                        <span class="home-hotels_card_badge <?= $badge['class'] ?>">
                            <?= $badge['label'] ?>
                        </span>

                    </div>

                    <div class="home-hotels_card_body">

                        <!-- hotel_name from Hotel table -->
                        <h3 class="home-hotels_card_name">
                            <?= htmlspecialchars($hotel['hotel_name']) ?>
                        </h3>

                        <!-- hotel_rating → filled/empty star string + numeric value -->
                        <div class="home-hotels_card_rating">
                            <span class="home-hotels_card_stars"><?= $stars ?></span>
                            <span class="home-hotels_card_ratingNum"><?= $rating ?></span>
                        </div>

                        <!--
                            hotel_address from Hotel table
                            shown as the location line under the stars
                            hotel_city is also available: $hotel['hotel_city']
                        -->
                        <p class="home-hotels_card_location">
                            <?= htmlspecialchars($hotel['hotel_address']) ?>,
                            <?= htmlspecialchars($hotel['hotel_city']) ?>
                        </p>

                        <!-- hotel_details from Hotel table → description paragraph -->
                        <p class="home-hotels_card_desc">
                            <?= htmlspecialchars($hotel['hotel_details']) ?>
                        </p>

                        <a href="booking.php?hotel_id=<?= $hotel['hotel_id'] ?>" class="home-book-btn">Book Now</a>

                    </div>

                </div>
                <!-- end of hotel card -->

            <?php endforeach; ?>

        </div>
        <!-- end of hotels cards grid -->

    </section>
    <!-- end of hotels section -->


    <!-- ================================
         AMENITIES SECTION
    ================================ -->
    <section id="amenities">

        <!-- Section Header -->
        <div class="home-amenities_header">
            <div class="home-amenities_headerText">
                <p class="home-amenities_tag">What We Offer</p>
                <h2 class="home-amenities_title">World-Class Amenities</h2>
                <p class="home-amenities_sub">
                    Every detail curated for your comfort and pleasure.
                </p>
            </div>
        </div>
        <!-- end of amenities header -->

        <!-- Amenities Grid -->
        <div class="home-amenities_grid">

            <div class="home-amenities_card">
                <h3 class="home-amenities_name">Infinity Pool</h3>
                <p class="home-amenities_desc">
                    Open sunrise to midnight with heated water
                    and private cabanas.
                </p>
            </div>

            <div class="home-amenities_card">
                <h3 class="home-amenities_name">Fine Dining</h3>
                <p class="home-amenities_desc">
                    Five-star cuisine by award-winning chefs.
                    Breakfast, lunch and dinner.
                </p>
            </div>

            <div class="home-amenities_card">
                <h3 class="home-amenities_name">Luxury Spa</h3>
                <p class="home-amenities_desc">
                    Full-service wellness center with massage,
                    sauna and beauty treatments.
                </p>
            </div>

            <div class="home-amenities_card">
                <h3 class="home-amenities_name">Fitness Center</h3>
                <p class="home-amenities_desc">
                    State-of-the-art equipment with personal
                    training available 24/7.
                </p>
            </div>

        </div>
        <!-- end of amenities grid -->

    </section>
    <!-- end of amenities section -->


    <!-- ================================
         OUR LOCATIONS SECTION
    ================================ -->
    <section id="about">

        <!-- Section Header -->
        <div class="home-locations_header">
            <p class="home-locations_tag">Where We Are</p>
            <h2 class="home-locations_title">Our Locations</h2>
            <p class="home-locations_sub">
                From city icons to hidden coastal retreats — find us where it matters most.
            </p>
        </div>
        <!-- end of locations header -->

        <!--
            $city_counts is built from:
            SELECT hotel_city, COUNT(*) AS hotels_count FROM Hotel GROUP BY hotel_city

            Each card reads: $city_counts['Cairo'] ?? 0
            The ?? 0 means "show 0 if that city has no hotels yet"
            So the number updates automatically when hotels are added to the DB
        -->

        <!-- Locations Grid: large left + 2 stacked right -->
        <div class="home-locations_grid">

            <!-- Large left card — Cairo -->
            <div class="home-locations_card home-locations_card--tall">
                <div class="home-locations_card_bg"
                     style="background-image: url('https://images.unsplash.com/photo-1572252009286-268acec5ca0a?w=900&q=80');"></div>
                <div class="home-locations_card_overlay"></div>
                <div class="home-locations_card_text">
                    <!-- hotel_city value used as key into $city_counts -->
                    <p class="home-locations_card_city">Cairo</p>
                    <!-- hotels_count → total Hotel rows WHERE hotel_city = 'Cairo' -->
                    <p class="home-locations_card_count">
                        <?= $city_counts['Cairo'] ?? 0 ?> Hotels Available
                    </p>
                </div>
            </div>

            <!-- Right column: 2 stacked cards -->
            <div class="home-locations_col">

                <!-- Alexandria -->
                <div class="home-locations_card home-locations_card--short">
                    <div class="home-locations_card_bg"
                         style="background-image: url('https://images.unsplash.com/photo-1539768942893-daf53e448371?w=700&q=80');"></div>
                    <div class="home-locations_card_overlay"></div>
                    <div class="home-locations_card_text">
                        <p class="home-locations_card_city">Alexandria</p>
                        <p class="home-locations_card_count">
                            <?= $city_counts['Alexandria'] ?? 0 ?> Hotels Available
                        </p>
                    </div>
                </div>

                <!-- Dubai -->
                <div class="home-locations_card home-locations_card--short">
                    <div class="home-locations_card_bg"
                         style="background-image: url('https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=700&q=80');"></div>
                    <div class="home-locations_card_overlay"></div>
                    <div class="home-locations_card_text">
                        <p class="home-locations_card_city">Dubai</p>
                        <p class="home-locations_card_count">
                            <?= $city_counts['Dubai'] ?? 0 ?> Hotels Available
                        </p>
                    </div>
                </div>

            </div>
            <!-- end of right column -->

        </div>
        <!-- end of main grid -->

        <!-- Bottom row: 2 wide cards -->
        <div class="home-locations_grid_bottom" style="margin-top: 16px;">

            <!-- London -->
            <div class="home-locations_card home-locations_card--wide">
                <div class="home-locations_card_bg"
                     style="background-image: url('https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800&q=80');"></div>
                <div class="home-locations_card_overlay"></div>
                <div class="home-locations_card_text">
                    <p class="home-locations_card_city">London</p>
                    <p class="home-locations_card_count">
                        <?= $city_counts['London'] ?? 0 ?> Hotels Available
                    </p>
                </div>
            </div>

            <!-- New York -->
            <div class="home-locations_card home-locations_card--wide">
                <div class="home-locations_card_bg"
                     style="background-image: url('https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800&q=80');"></div>
                <div class="home-locations_card_overlay"></div>
                <div class="home-locations_card_text">
                    <p class="home-locations_card_city">New York</p>
                    <p class="home-locations_card_count">
                        <?= $city_counts['New York'] ?? 0 ?> Hotels Available
                    </p>
                </div>
            </div>

        </div>
        <!-- end of bottom row -->

    </section>
    <!-- end of locations section -->


    <!-- ================================
         FOOTER
    ================================ -->
    <footer id="contact">

        <!-- Top Grid: Brand + Links -->
        <div class="home-footer_grid">

            <!-- Column 1: Brand -->
            <div class="home-footer_brand">
                <p class="home-footer_logo">StayEase</p>
                <p class="home-footer_tagline">
                    The modern way to discover and book premium
                    hotel accommodations worldwide.
                </p>
            </div>

            <!-- Column 2: Quick Links -->
            <div class="home-footer_col">
                <h4 class="home-footer_colTitle">Quick Links</h4>
                <ul class="home-footer_links">
                    <li><a href="hotels.php">All Hotels</a></li>
                    <li><a href="#amenities">Amenities</a></li>
                    <li><a href="login.php">Sign In</a></li>
                    <li><a href="register.php">Register</a></li>
                </ul>
            </div>

            <!-- Column 3: Contact -->
            <div class="home-footer_col">
                <h4 class="home-footer_colTitle">Contact Us</h4>
                <div class="home-footer_contact">
                    <p class="home-footer_contactEmail">stayease@gmail.com</p>
                </div>
            </div>

        </div>
        <!-- end of footer grid -->

        <!-- Bottom Bar -->
        <div class="home-footer_bottom">
            <p class="home-footer_copyright">© 2025 StayEase. All rights reserved.</p>
            <p class="home-footer_credit">Built with  for exceptional stays.</p>
        </div>
        <!-- end of bottom bar -->

    </footer>
    <!-- end of footer -->


<script>

  /* ================================
     DATE VALIDATION
     (kept for search pages)
  ================================ */

  const checkinInput  = document.getElementById('checkin');
  const checkoutInput = document.getElementById('checkout');

  if (checkinInput && checkoutInput) {

    checkoutInput.addEventListener('change', function() {
      const checkinDate  = new Date(checkinInput.value);
      const checkoutDate = new Date(checkoutInput.value);
      if (checkoutDate <= checkinDate) {
        alert('Check-out date must be after check-in date.');
        checkoutInput.value = '';
      }
    });

    const today = new Date().toISOString().split('T')[0];
    checkinInput.setAttribute('min', today);

    checkinInput.addEventListener('change', function() {
      checkoutInput.setAttribute('min', this.value);
      if (checkoutInput.value && checkoutInput.value <= this.value) {
        checkoutInput.value = '';
      }
    });

  }

</script>

</body>
</html>
