<?php
// - login.php (no 'name' column required) -
require_once 'config.php';
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: home.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$username || !$password) {
        $error = 'Please enter your username and password.';
    } else {
        // Only select columns that exist: user_id, username, password
        $stmt = $conn->prepare("SELECT user_id, username, password FROM User WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if (!$user) {
            $error = 'No account found with that username.';
        } elseif (!password_verify($password, $user['password'])) {
            $error = 'Incorrect password.';
        } else {
            // Store username in session (it will be displayed on every page)
            $_SESSION['user_id']   = $user['user_id'];
            $_SESSION['user_name'] = $user['username'];   // this is the username

            $redirect = $_GET['redirect'] ?? 'home.php';
            header('Location: ' . $redirect);
            exit;
        }
        $stmt->close();
    }
}
?>

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — StayEase</title>
<!-- your existing CSS (keep as is) -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  /* Keep your original style – unchanged */
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --gold: #C9A96E; --gold-light: #E8D5B0; --gold-dark: #8B6914;
    --navy: #0D1B2A; --navy-mid: #1A2E42; --navy-soft: #243447;
    --cream: #FAF7F2; --cream-mid: #F0EBE1;
    --text-dark: #0D1B2A; --text-mid: #4A5568; --text-light: #8A9BA8;
    --white: #FFFFFF;
  }
  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--navy);
    color: var(--text-dark);
    min-height: 100vh;
    display: flex;
    align-items: stretch;
  }
  a { text-decoration: none; }
  .auth-left {
    flex: 1;
    position: relative;
    overflow: hidden;
    display: flex;
    align-items: flex-end;
    padding: 60px;
  }
  .auth-left-bg {
    position: absolute; inset: 0;
    background-image: url('https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1200&q=80');
    background-size: cover;
    background-position: center;
    opacity: 0.3;
  }
  .auth-left-overlay {
    position: absolute; inset: 0;
    background: linear-gradient(to top, rgba(13,27,42,0.95) 0%, rgba(13,27,42,0.4) 60%, transparent 100%);
  }
  .auth-left-content { position: relative; z-index: 2; }
  .auth-logo {
    font-family: 'Cormorant Garamond', serif;
    font-size: 36px;
    font-weight: 500;
    color: var(--gold);
    letter-spacing: 2px;
    margin-bottom: 20px;
    display: block;
  }
  .auth-logo span { color: var(--white); }
  .auth-left-title {
    font-family: 'Cormorant Garamond', serif;
    font-size: 48px;
    font-weight: 300;
    color: var(--white);
    line-height: 1.1;
    margin-bottom: 14px;
  }
  .auth-left-title em { font-style: italic; color: var(--gold); }
  .auth-left-sub {
    font-size: 14px;
    color: rgba(255,255,255,0.45);
    max-width: 320px;
    line-height: 1.7;
  }
  .auth-right {
    width: 480px;
    flex-shrink: 0;
    background: var(--cream);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 60px 48px;
  }
  .auth-form-wrap { width: 100%; }
  .auth-tag {
    font-size: 11px;
    letter-spacing: 3px;
    text-transform: uppercase;
    color: var(--gold);
    margin-bottom: 10px;
  }
  .auth-title {
    font-family: 'Cormorant Garamond', serif;
    font-size: 40px;
    font-weight: 400;
    color: var(--text-dark);
    margin-bottom: 32px;
    line-height: 1.1;
  }
  label {
    display: block;
    font-size: 11px;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--text-light);
    font-weight: 500;
    margin-bottom: 8px;
  }
  input {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid var(--cream-mid);
    border-radius: 4px;
    font-size: 14px;
    font-family: 'DM Sans', sans-serif;
    background: var(--white);
    color: var(--text-dark);
    transition: border-color 0.2s;
    margin-bottom: 20px;
  }
  input:focus { outline: none; border-color: var(--gold); }
  .btn-auth {
    width: 100%;
    padding: 15px;
    background: var(--gold);
    color: var(--navy);
    border: none;
    border-radius: 4px;
    font-family: 'Cormorant Garamond', serif;
    font-size: 18px;
    font-weight: 500;
    letter-spacing: 1px;
    cursor: pointer;
    transition: background 0.2s;
    margin-top: 4px;
  }
  .btn-auth:hover { background: var(--gold-light); }
  .auth-switch {
    margin-top: 24px;
    text-align: center;
    font-size: 13px;
    color: var(--text-light);
  }
  .auth-switch a { color: var(--gold-dark); font-weight: 500; }
  .auth-switch a:hover { color: var(--gold); }
  .alert-error {
    background: #FDF0F0;
    border-left: 3px solid #C0392B;
    color: #7B2020;
    padding: 12px 16px;
    border-radius: 4px;
    font-size: 13px;
    margin-bottom: 20px;
  }
  @media (max-width: 820px) {
    body { flex-direction: column; }
    .auth-left { min-height: 260px; flex: none; padding: 40px 24px; }
    .auth-right { width: 100%; padding: 40px 24px; }
  }
</style>
</head>
<body>

<div class="auth-left">
  <div class="auth-left-bg"></div>
  <div class="auth-left-overlay"></div>
  <div class="auth-left-content">
    <a href="home.php" class="auth-logo">Stay<span>Ease</span></a>
    <h1 class="auth-left-title">Welcome <em>back.</em></h1>
    <p class="auth-left-sub">Sign in to manage your bookings and discover your next exceptional stay.</p>
  </div>
</div>

<div class="auth-right">
  <div class="auth-form-wrap">
    <p class="auth-tag">Account</p>
    <h2 class="auth-title">Sign In</h2>

    <?php if ($error): ?>
      <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div>
        <label for="username">Username</label>
        <input type="text" id="username" name="username"
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
               placeholder="Your username" required autofocus>
      </div>
      <div>
        <label for="password">Password</label>
        <input type="password" id="password" name="password"
               placeholder="Your password" required>
      </div>
      <button type="submit" class="btn-auth">Sign In</button>
    </form>

    <p class="auth-switch">
      No account? <a href="register.php">Create one</a>
    </p>
  </div>
</div>

</body>
</html>